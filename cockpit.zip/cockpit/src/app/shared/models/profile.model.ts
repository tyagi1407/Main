export class Profile {
    public userID: string;
    public userName: string;
    //TODO:add other profile properties later

    
    constructor(public userIDParam: string, public userNameParam: string) {
        this.userID = this.userIDParam;
        this.userName = this.userNameParam;
        
    }




}