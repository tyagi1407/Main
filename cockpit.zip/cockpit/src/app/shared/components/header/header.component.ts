import { Component, OnInit } from '@angular/core';
//user-defined imports
import { interval } from 'rxjs';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { ProfileService } from 'src/app/core/services/profile.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'flymon-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  loginUser: string;
  today = new Date().toISOString();
  imgSwap: string = "assets/Topfilter_on.png";
  profiles: string[];
  station: string;

  constructor(private adalService: MsAdalAngular6Service, private profileService: ProfileService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    //comment this in order to test without adfs locally   
    if (this.adalService.isAuthenticated) {
      this.loginUser = this.adalService.userInfo.profile.unique_name.replace("CORP\\", "");
      sessionStorage.setItem('user', this.loginUser);
    }
    else this.loginUser = sessionStorage.getItem('user');

    //set url params   
    this.route.params.subscribe(params => {
      if (params['station']) {
        var stn = params['station'];
        this.station = stn;
        //console.log(this.station);
      }
    });
    this.getPublicProfiles();

    var t = interval(30000);    //get data on specific interval
    t.subscribe(val => {
      this.today = new Date().toISOString();
    }
    );


  }

  getPublicProfiles() {
    this.profileService.getProfileNames('public').subscribe(
      data => {
        this.profiles = data;
        //console.log(this.profiles);
      },
      error => { }
    )

  }

}

