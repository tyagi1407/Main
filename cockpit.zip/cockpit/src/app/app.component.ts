import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//user-defined imports
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  //private token: string;
  private apitokenURL: string = environment.apiTokenURL;

  constructor(private adalService: MsAdalAngular6Service, private http: HttpClient) { }

  ngOnInit() {
    if (environment.production) this.adalLogin();
    else sessionStorage.setItem('user', 'gt305655');
  }

  private adalLogin(): any {

    //handle callback if this is a redirect from adfs
    this.adalService.handleCallback();

    //call the login method to get id_token
    if (!this.adalService.isAuthenticated) {
      this.adalService.login();
    }

    //get the access_token for the resource if login is successfull
    //this.adalService.acquireToken(this.apitokenURL).subscribe();

    //adal saves the token in session storage
    //console.log('token from session ' + sessionStorage.getItem('adal.idtoken'));

  }


  //#region To be removed later- This will be used by angular elements in get/post calls
  private authenticateToken(token: string): any {
    return this.http.post(this.apitokenURL, this.getADFSHeaders(token));
  }
  private getADFSHeaders(token: string): any {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
      })
    };
    return httpOptions;
  }
  //#endregion

}

