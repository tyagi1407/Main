import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { FlightDetailDepartureComponent } from './components/flight-detail-departure/flight-detail-departure.component';
import { FlightDetailArrivalComponent } from './components/flight-detail-arrival/flight-detail-arrival.component';
import { HistoryComponent } from './components/history/history.component';


const flightRoutes: Routes = [
  //{ path: 'home', component: HomeComponent },
  { path: 'home/:station', component: HomeComponent },
  { path: 'home', redirectTo: '/home/zrh', pathMatch: 'full' },
  { path: 'departureDetail/:station', component: FlightDetailDepartureComponent },
  { path: 'arrivalDetail/:station', component: FlightDetailArrivalComponent },
  { path: 'history/:station', component: HistoryComponent },
  { path: '', redirectTo: '/home/zrh', pathMatch: 'full' },
  { path: '**', component: HomeComponent }  //ToDO:implement error page
];

@NgModule({
  imports: [RouterModule.forChild(flightRoutes)],
  exports: [RouterModule]
})
export class FlightRoutingModule { }
