import { Component, OnInit, ViewChild, Input, HostListener, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatPaginatorIntl } from '@angular/material';
import { FormControl } from '@angular/forms';
import { FlightService } from './../../../core/services/flight.service'
import { FlightMockService } from './../../../core/mocks/flight-mock.service';
import { Flight } from '../../models/flight.model';
import { environment } from 'src/environments/environment';
import { ExportAsService, ExportAsConfig } from 'ngx-export-as';
import { PrintService } from './../../../core/services/print.service';
import { interval, combineLatest } from 'rxjs';
import { map } from 'rxjs/operators';
import { FlymonFlight } from '../../models/flymon-flight.model';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { CdkDragStart, CdkDropList, moveItemInArray } from '@angular/cdk/drag-drop';


@Component({
  selector: 'flymon-departure',
  templateUrl: './departure.component.html',
  styleUrls: ['./departure.component.css']
})

export class DepartureComponent implements OnInit {

  //variables
  columnArrayLength: number;
  filterArrayLength: number;
  //showDeparture: boolean = false;
  //showDwnloadIcons: boolean = false;
  //showDepClmSlctPanel: boolean = false;
  depFileName: string = "FlymonDepFlt";
  totalDeparture: number;
  flightArray: Flight[] = [];
  flymonFlightArray: FlymonFlight[];
  mock: boolean = environment.mock;
  depStation: string = 'ZRH'; //default station  
  hour = 3;
  depFrom = new Date(Date.now() - this.hour * 60 * 60 * 1000).toISOString();
  depTo = new Date(Date.now() + this.hour * 60 * 60 * 1000).toISOString();
  //depFrom: string;
  //depTo: string;
  selectedRowKey: string;
  //lastApiCallTime: Date = new Date();
  loader: boolean = true;
  previousIndex: number;
  @Input() public depFilterJson: string;

  //file export configurations
  exportAsConfigPdf: ExportAsConfig = { type: 'pdf', elementId: 'depExport', options: { orientation: 'landscape', margins: { top: '20' } } }
  exportAsConfigCsv: ExportAsConfig = { type: 'csv', elementId: 'depExport' }
  exportAsConfigExcel: ExportAsConfig = { type: 'xlsx', elementId: 'depExport' }
  //material variables
  //dataLength: number = this.flightArray.length;
  //pageLength: number = 80;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  //paginator: MatPaginator = new MatPaginator(new MatPaginatorIntl(), this.ref);
  @ViewChild(MatSort) sort: MatSort;
  //#region form controls
  depflkFilter = new FormControl('');
  depatcFilter = new FormControl('');
  depfltFilter = new FormControl('');
  depdesFilter = new FormControl('');
  depstdFilter = new FormControl('');
  depetdFilter = new FormControl('');
  depadvFilter = new FormControl('');
  depatdFilter = new FormControl('');
  depgatFilter = new FormControl('');
  deptarFilter = new FormControl('');
  depremFilter = new FormControl('');
  deppbtFilter = new FormControl('');
  deplkfFilter = new FormControl('');
  depsdtFilter = new FormControl('');
  depgstFilter = new FormControl('');
  depir1Filter = new FormControl('');
  deptypFilter = new FormControl('');
  depschFilter = new FormControl('');
  deptorFilter = new FormControl('');
  depmisFilter = new FormControl('');
  depabfFilter = new FormControl('');
  depabtFilter = new FormControl('');
  depad1Filter = new FormControl('');
  depad2Filter = new FormControl('');
  depad3Filter = new FormControl('');
  depadcFilter = new FormControl('');
  depaefFilter = new FormControl('');
  depaotFilter = new FormControl('');
  depasbFilter = new FormControl('');
  depassFilter = new FormControl('');
  depbttFilter = new FormControl('');
  depcirFilter = new FormControl('');
  depcleFilter = new FormControl('');
  deppaxFilter = new FormControl('');
  deppscFilter = new FormControl('');
  depmgtFilter = new FormControl('');
  depmidFilter = new FormControl('');
  deplmfFilter = new FormControl('');
  deppcbFilter = new FormControl('');
  depsedFilter = new FormControl('');
  //#endregion
  public actualColumns: string[] = ['FLT', 'DES', 'SDT', 'STD', 'ETD', 'ATD', 'ATC', 'GAT', 'GST', 'TAR', 'IR1', 'TYP', 'SCH', 'ADV', 'REM', 'PBT', 'LKF', 'TOR', 'MIS', 'ABF', 'ABT', 'AD1', 'AD2', 'AD3', 'ADC', 'AEF', 'AOT', 'ASB	', 'ASS', 'BTT', 'CIR', 'CLE', 'PAX', 'PSC', 'MGT', 'MID', 'LMF', 'PCB', 'SED'];
  public displayedColumns: string[];//= ['FLT', 'DES', 'SDT', 'STD', 'ETD', 'ATD', 'SCH', 'LKF'];
  public actualFilters: string[] = ['FLT-filter', 'DES-filter', 'SDT-filter', 'STD-filter', 'ETD-filter', 'ATD-filter', 'ATC-filter', 'GAT-filter', 'GST-filter', 'TAR-filter', 'IR1-filter', 'TYP-filter', 'SCH-filter', 'ADV-filter', 'REM-filter', 'PBT-filter', 'LKF-filter', 'TOR-filter', 'MIS-filter', 'ABF-filter', 'ABT-filter', 'AD1-filter', 'AD2-filter', 'AD3-filter', 'ADC-filter', 'AEF-filter', 'AOT-filter', 'ASB-filter', 'ASS-filter', 'BTT-filter', 'CIR-filter', 'CLE-filter', 'PAX-filter', 'PSC-filter', 'MGT-filter', 'MID-filter', 'LMF-filter', 'PCB-filter', 'SED-filter'];
  public displayedFilters: string[];//= ['FLT-filter', 'DES-filter', 'SDT-filter', 'STD-filter', 'ETD-filter', 'ATD-filter', 'SCH-filter', 'LKF-filter']
  public dataSource = new MatTableDataSource<Flight>();
  filterValues = { FLT: '', DES: '', SDT: '', STD: '', ETD: '', ATD: '', ATC: '', GAT: '', GST: '', TAR: '', IR1: '', TYP: '', SCH: '', ADV: '', REM: '', PBT: '', LKF: '', TOR: '', MIS: '', ABF: '', ABT: '', AD1: '', AD2: '', AD3: '', ADC: '', AEF: '', AOT: '', ASB: '', ASS: '', BTT: '', CIR: '', CLE: '', PAX: '', PSC: '', MGT: '', MID: '', LMF: '', PCB: '', SED: '' };


  constructor(private route: ActivatedRoute, private router: Router, private ref: ChangeDetectorRef, private printService: PrintService, private exportAsService: ExportAsService,
    private flightService: FlightService, private flightMockService: FlightMockService, private datePipe: DatePipe) {

  }

  ngOnInit() {

    //set url params
    combineLatest(this.route.params, this.route.queryParams)
      .pipe(map(results => ({ params: results[0].station, queryParams: results[1] })))
      .subscribe(results => {
        var stn = results.params;
        this.depStation = stn.toUpperCase();
        if (results.queryParams.from || results.queryParams.to) {
          this.setFilterParameters(results.queryParams);
        }
        //if (this.router.url.toLowerCase().toString().indexOf('profile') ==-1)
        this.getDepartureFlightData(true);    //get data on search parameters selection  
      });

    if (this.mock) {
      this.flightArray = this.flightMockService.getFlights();   //TODO:change mock array to receive new format
      this.totalDeparture = this.flightArray.length;
      this.dataSource.data = this.flightArray;
      this.dataSource.filterPredicate = this.createFilter();
    }
    else {
      var t = interval(30000);//get data on specific interval
      t.subscribe(val => {
        if (this.router.url.toLowerCase().toString().indexOf('create-profile') == -1)
          this.getDepartureFlightData();
      }
      );
    }
    //#region material events 
    //this.paginator.pageSize = this.pageLength;
    //this.paginator.ngOnInit();
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    this.depfltFilter.valueChanges.subscribe(x => { this.filterValues.FLT = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depdesFilter.valueChanges.subscribe(x => { this.filterValues.DES = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depsdtFilter.valueChanges.subscribe(x => { this.filterValues.SDT = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depstdFilter.valueChanges.subscribe(x => { this.filterValues.STD = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depetdFilter.valueChanges.subscribe(x => { this.filterValues.ETD = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depatdFilter.valueChanges.subscribe(x => { this.filterValues.ATD = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depatcFilter.valueChanges.subscribe(x => { this.filterValues.ATC = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depgatFilter.valueChanges.subscribe(x => { this.filterValues.GAT = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depgstFilter.valueChanges.subscribe(x => { this.filterValues.GST = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.deptarFilter.valueChanges.subscribe(x => { this.filterValues.TAR = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depir1Filter.valueChanges.subscribe(x => { this.filterValues.IR1 = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.deptypFilter.valueChanges.subscribe(x => { this.filterValues.TYP = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depschFilter.valueChanges.subscribe(x => { this.filterValues.SCH = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depadvFilter.valueChanges.subscribe(x => { this.filterValues.ADV = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depremFilter.valueChanges.subscribe(x => { this.filterValues.REM = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.deppbtFilter.valueChanges.subscribe(x => { this.filterValues.PBT = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.deplkfFilter.valueChanges.subscribe(x => { this.filterValues.LKF = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.deptorFilter.valueChanges.subscribe(x => { this.filterValues.TOR = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depmisFilter.valueChanges.subscribe(x => { this.filterValues.MIS = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depabfFilter.valueChanges.subscribe(x => { this.filterValues.ABF = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depabtFilter.valueChanges.subscribe(x => { this.filterValues.ABT = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depad1Filter.valueChanges.subscribe(x => { this.filterValues.AD1 = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depad2Filter.valueChanges.subscribe(x => { this.filterValues.AD2 = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depad3Filter.valueChanges.subscribe(x => { this.filterValues.AD3 = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depadcFilter.valueChanges.subscribe(x => { this.filterValues.ADC = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depaefFilter.valueChanges.subscribe(x => { this.filterValues.AEF = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depaotFilter.valueChanges.subscribe(x => { this.filterValues.AOT = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depasbFilter.valueChanges.subscribe(x => { this.filterValues.ASB = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depassFilter.valueChanges.subscribe(x => { this.filterValues.ASS = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depbttFilter.valueChanges.subscribe(x => { this.filterValues.BTT = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depcirFilter.valueChanges.subscribe(x => { this.filterValues.CIR = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depcleFilter.valueChanges.subscribe(x => { this.filterValues.CLE = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.deppaxFilter.valueChanges.subscribe(x => { this.filterValues.PAX = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.deppscFilter.valueChanges.subscribe(x => { this.filterValues.PSC = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depmgtFilter.valueChanges.subscribe(x => { this.filterValues.MGT = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depmidFilter.valueChanges.subscribe(x => { this.filterValues.MID = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.deplmfFilter.valueChanges.subscribe(x => { this.filterValues.LMF = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.deppcbFilter.valueChanges.subscribe(x => { this.filterValues.PCB = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    this.depsedFilter.valueChanges.subscribe(x => { this.filterValues.SED = x; this.depFilterJson = JSON.stringify(this.filterValues); this.dataSource.filter = JSON.stringify(this.filterValues); });
    //#endregion
  }

  setFilterParameters(params: Params) {   //set filters
    //console.log(params);    
    if (params.from)
      this.depFrom = params.from
    if (params.to)
      this.depTo = params.to;
  }

  getDepartureFlightData(firstLoad: boolean = false) {    //get departure flight data based on parameters  
    this.loader = true;
    this.flightService.getFlightsFromStation(this.depStation, 'departure', this.depFrom, this.depTo).subscribe(
      data => {
        this.flymonFlightArray = data;
        this.transformDepFlightArray(firstLoad);
        //this.lastApiCallTime = new Date();
        this.loader = false;
      },
      res => {
        if (res) {
          if (res.status !== 200) {  //TODO: 
            this.flymonFlightArray = [];
            this.transformDepFlightArray(firstLoad);
            this.loader = false;
            //console.log(res.message);
          }
        }
      }
      //err => console.error('error received getDepartureFlightData: ' + err)
    )
  }

  transformDepFlightArray(firstLoad: boolean = false) {
    this.flightArray = [];
    //console.log('departure data received from api: ' + JSON.stringify(this.flymonFlightArray));
    this.flymonFlightArray.forEach((item) => {
      if (item) {
        this.flightArray.push({
          FLK: item.FLK,
          FLT: item.FLC + item.FLN.toString(),
          FLN: item.FLN.toString(),
          FLC: item.FLC,
          ORG: item.ORG,
          DES: item.DES,
          SDT: this.datePipe.transform(item.departureTimes.STD, 'yy/MM/dd') == null ? "" : this.datePipe.transform(item.departureTimes.STD, 'yy/MM/dd').toString(),
          STD: this.datePipe.transform(item.departureTimes.STD, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.STD, 'HH:mm').toString(),
          ETD: this.datePipe.transform(item.departureTimes.ETD, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.ETD, 'HH:mm').toString(),
          ATD: this.datePipe.transform(item.departureTimes.ATD, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.ATD, 'HH:mm').toString(),
          ATC: item.departureTimes.ATC,
          GAT: item.departureAirports.GAT,
          GST: item.departureAirports.GST,
          TAR: item.departureAirports.TAR,
          IR1: item.departureDelays.IR1 == null ? "" : item.departureDelays.IR1,
          TYP: item.departureAircrafts.TYP,
          SCH: item.DMI,
          ADV: this.datePipe.transform(item.departureTimes.ADV, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.ADV, 'HH:mm').toString(),
          REM: item.REM,
          PBT: item.departurePassengers.PBT == null ? "" : item.departurePassengers.PBT.toString(),
          LKF: item.departureLinkAndShare.LKF,
          //UPD: new Date(this.datePipe.transform(item.SDM, 'E, d MMM yyyy HH:mm:ss Z').toString()) > this.lastApiCallTime ? '1' : '0',
          UPD: this.getDateDifferenceInMinutes(new Date(this.datePipe.transform(item.SDM, 'E, d MMM yyyy HH:mm:ss Z').toString()), new Date()) <= 5 ? '1' : '0',
          TOR: item.departureAircrafts.TOR,
          MIS: item.MIS,
          ABF: this.datePipe.transform(item.departureTimes.ABF, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.ABF, 'HH:mm').toString(),
          ABT: this.datePipe.transform(item.departureTimes.ABT, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.ABT, 'HH:mm').toString(),
          AD1: this.datePipe.transform(item.departureTimes.AD1, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.AD1, 'HH:mm').toString(),
          AD2: this.datePipe.transform(item.departureTimes.AD2, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.AD2, 'HH:mm').toString(),
          AD3: this.datePipe.transform(item.departureTimes.AD3, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.AD3, 'HH:mm').toString(),
          ADC: this.datePipe.transform(item.departureTimes.ADC, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.ADC, 'HH:mm').toString(),
          AEF: this.datePipe.transform(item.departureTimes.AEF, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.AEF, 'HH:mm').toString(),
          AOT: this.datePipe.transform(item.departureTimes.AOT, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.AOT, 'HH:mm').toString(),
          ASB: item.departureTimes.ASB,
          ASS: this.datePipe.transform(item.departureTimes.ASS, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.ASS, 'HH:mm').toString(),
          BTT: this.datePipe.transform(item.departureTimes.BTT, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.BTT, 'HH:mm').toString(),
          CIR: item.departureAirports.CIR,
          CLE: this.datePipe.transform(item.departureTimes.CLE, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.CLE, 'HH:mm').toString(),
          PAX: item.departurePassengers.PAX == null ? "" : item.departurePassengers.PAX.toString(),
          PSC: "-",
          MGT: item.departureTimes.MGT,
          MID: item.departureAirports.MID,
          LMF: item.departureAircrafts.LMF,
          PCB: item.departurePassengers.PCB == null ? "" : item.departurePassengers.PCB.toString(),
          SED: this.datePipe.transform(item.departureTimes.SED, 'HH:mm') == null ? "" : this.datePipe.transform(item.departureTimes.SED, 'HH:mm').toString(),
          //arrival fields empty
          ATA: "",
          STA: "",
          ETA: "",
          DEL: "",
          LTD: "",
          LTA: "",
          VI1: "",
          VI2: "",
          TER: "",
          TDT: "",
          STP: "",
          MSA: "",
          MIA: "",
          LKR: "",
          FCD: "",
          FCC: "",
          EDP: ""
        });
      }
    });

    //console.log('departure data after mapping: ' + JSON.stringify(this.flightArray));
    this.totalDeparture = this.flightArray.length;
    this.dataSource.data = this.flightArray;
    if (firstLoad) {
      this.dataSource.filterPredicate = this.createMultivalueFilter();
      //console.log(this.depFilterJson);
      if (this.depFilterJson.length > 0) {
        this.dataSource.filter = this.depFilterJson;//TODO:check if required on first load?
        this.displayedColumns = this.flightService.getPropertyNamesFromJson(this.depFilterJson);
      }
      else {
        //default columns if error received from profile api         
        this.displayedColumns = ['FLT', 'DES', 'SDT', 'STD', 'ETD', 'ATD', 'GAT', 'TAR', 'SCH', 'LKF'];
      }

      this.displayedFilters = this.displayedColumns.map(item => item + '-filter');
      //console.log(this.displayedColumns);
      //console.log(this.displayedFilters);
    }

  }

  //#region file export functions  
  exportDepPdf() { this.exportAsService.save(this.exportAsConfigPdf, this.depFileName + new Date().toISOString().slice(0, 10)); }
  exportDepCsv() { this.exportAsService.save(this.exportAsConfigCsv, this.depFileName + new Date().toISOString().slice(0, 10)); }
  exportDepExcel() { this.exportAsService.save(this.exportAsConfigExcel, this.depFileName + new Date().toISOString().slice(0, 10)); }
  //#endregion

  //#region print function 
  printDeparture(htmlSectionId: string) {
    this.printService.print(htmlSectionId, 'AFIS DEPARTURE');
  }
  //#endregion

  //#region material functions

  getRegularExpression(value: string): RegExp {
    let searchArray: string[] = value.split(',');
    return new RegExp(searchArray.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));
  }

  //multi-value column filter using regex
  createMultivalueFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {
      let searchJsonObject = JSON.parse(filter);
      //currently FLT,ORG,DES,GAT,TAR,SCH columns have multivalue filter options, this can be extended if required
      let fltSearch: string[] = searchJsonObject.FLT ? searchJsonObject.FLT.split(',') : [""];
      var fltRegex = new RegExp(fltSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));
      let desSearch: string[] = searchJsonObject.DES ? searchJsonObject.DES.split(',') : [""];
      var desRegex = new RegExp(desSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));
      let gatSearch: string[] = searchJsonObject.GAT ? searchJsonObject.GAT.split(',') : [""];
      var gatRegex = new RegExp(gatSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));
      let tarSearch: string[] = searchJsonObject.TAR ? searchJsonObject.TAR.split(',') : [""];
      var tarRegex = new RegExp(tarSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));
      let schSearch: string[] = searchJsonObject.SCH ? searchJsonObject.SCH.split(',') : [""];
      var schRegex = new RegExp(schSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));

      return fltRegex.test((data.FLT == null ? "" : data.FLT).toLowerCase())
        && desRegex.test((data.DES == null ? "" : data.DES).toLowerCase())
        && gatRegex.test((data.GAT == null ? "" : data.GAT).toLowerCase())
        && tarRegex.test((data.TAR == null ? "" : data.TAR).toLowerCase())
        && schRegex.test((data.SCH == null ? "" : data.SCH).toLowerCase())
        && (data.SDT == null ? "" : data.SDT).toLowerCase().indexOf(searchJsonObject.SDT ? searchJsonObject.SDT : "") !== -1
        //&& (data.DES == null ? "" : data.DES).toLowerCase().indexOf(searchJsonObject.DES) !== -1
        && (data.STD == null ? "" : data.STD).toLowerCase().indexOf(searchJsonObject.STD ? searchJsonObject.STD : "") !== -1
        && (data.ETD == null ? "" : data.ETD).toLowerCase().indexOf(searchJsonObject.ETD ? searchJsonObject.ETD : "") !== -1
        && (data.ATD == null ? "" : data.ATD).toLowerCase().indexOf(searchJsonObject.ATD ? searchJsonObject.ATD : "") !== -1
        && (data.ATC == null ? "" : data.ATC).toLowerCase().indexOf(searchJsonObject.ATC ? searchJsonObject.ATC : "") !== -1
        //&& (data.GAT == null ? "" : data.GAT).toLowerCase().indexOf(searchJsonObject.GAT) !== -1
        && (data.GST == null ? "" : data.GST).toLowerCase().indexOf(searchJsonObject.GST ? searchJsonObject.GST : "") !== -1
        //&& (data.TAR == null ? "" : data.TAR).toLowerCase().indexOf(searchJsonObject.TAR) !== -1
        && (data.IR1 == null ? "" : data.IR1).toLowerCase().indexOf(searchJsonObject.IR1 ? searchJsonObject.IR1 : "") !== -1
        && (data.TYP == null ? "" : data.TYP).toLowerCase().indexOf(searchJsonObject.TYP ? searchJsonObject.TYP : "") !== -1
        //&& (data.SCH == null ? "" : data.SCH).toLowerCase().indexOf(searchJsonObject.SCH) !== -1
        && (data.ADV == null ? "" : data.ADV).toLowerCase().indexOf(searchJsonObject.ADV ? searchJsonObject.ADV : "") !== -1
        && (data.REM == null ? "" : data.REM).toLowerCase().indexOf(searchJsonObject.REM ? searchJsonObject.REM : "") !== -1
        && (data.PBT == null ? "" : data.PBT).toLowerCase().indexOf(searchJsonObject.PBT ? searchJsonObject.PBT : "") !== -1
        && (data.LKF == null ? "" : data.LKF).toLowerCase().indexOf(searchJsonObject.LKF ? searchJsonObject.LKF : "") !== -1
        && (data.TOR == null ? "" : data.TOR).toLowerCase().indexOf(searchJsonObject.TOR ? searchJsonObject.TOR : "") !== -1
        && (data.MIS == null ? "" : data.MIS).toLowerCase().indexOf(searchJsonObject.MIS ? searchJsonObject.MIS : "") !== -1
        && (data.ABF == null ? "" : data.ABF).toLowerCase().indexOf(searchJsonObject.ABF ? searchJsonObject.ABF : "") !== -1
        && (data.ABT == null ? "" : data.ABT).toLowerCase().indexOf(searchJsonObject.ABT ? searchJsonObject.ABT : "") !== -1
        && (data.AD1 == null ? "" : data.AD1).toLowerCase().indexOf(searchJsonObject.AD1 ? searchJsonObject.AD1 : "") !== -1
        && (data.AD2 == null ? "" : data.AD2).toLowerCase().indexOf(searchJsonObject.AD2 ? searchJsonObject.AD2 : "") !== -1
        && (data.AD3 == null ? "" : data.AD3).toLowerCase().indexOf(searchJsonObject.AD3 ? searchJsonObject.AD3 : "") !== -1
        && (data.ADC == null ? "" : data.ADC).toLowerCase().indexOf(searchJsonObject.ADC ? searchJsonObject.ADC : "") !== -1
        && (data.AEF == null ? "" : data.AEF).toLowerCase().indexOf(searchJsonObject.AEF ? searchJsonObject.AEF : "") !== -1
        && (data.AOT == null ? "" : data.AOT).toLowerCase().indexOf(searchJsonObject.AOT ? searchJsonObject.AOT : "") !== -1
        && (data.ASB == null ? "" : data.ASB).toLowerCase().indexOf(searchJsonObject.ASB ? searchJsonObject.ASB : "") !== -1
        && (data.ASS == null ? "" : data.ASS).toLowerCase().indexOf(searchJsonObject.ASS ? searchJsonObject.ASS : "") !== -1
        && (data.BTT == null ? "" : data.BTT).toLowerCase().indexOf(searchJsonObject.BTT ? searchJsonObject.BTT : "") !== -1
        && (data.CIR == null ? "" : data.CIR).toLowerCase().indexOf(searchJsonObject.CIR ? searchJsonObject.CIR : "") !== -1
        && (data.CLE == null ? "" : data.CLE).toLowerCase().indexOf(searchJsonObject.CLE ? searchJsonObject.CLE : "") !== -1
        && (data.PAX == null ? "" : data.PAX).toLowerCase().indexOf(searchJsonObject.PAX ? searchJsonObject.PAX : "") !== -1
        && (data.PSC == null ? "" : data.PSC).toLowerCase().indexOf(searchJsonObject.PSC ? searchJsonObject.PSC : "") !== -1
        && (data.MGT == null ? "" : data.MGT).toLowerCase().indexOf(searchJsonObject.MGT ? searchJsonObject.MGT : "") !== -1
        && (data.MID == null ? "" : data.MID).toLowerCase().indexOf(searchJsonObject.MID ? searchJsonObject.MID : "") !== -1
        && (data.LMF == null ? "" : data.LMF).toLowerCase().indexOf(searchJsonObject.LMF ? searchJsonObject.LMF : "") !== -1
        && (data.PCB == null ? "" : data.PCB).toLowerCase().indexOf(searchJsonObject.PCB ? searchJsonObject.PCB : "") !== -1
        && (data.SED == null ? "" : data.SED).toLowerCase().indexOf(searchJsonObject.SED ? searchJsonObject.SED : "") !== -1
    }
    return filterFunction;
  }
  //simple column filter
  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {
      this.searchJson = filter;
      let searchJsonObject = JSON.parse(filter);
      return (data.FLT == null ? "" : data.FLT).toLowerCase().indexOf(searchJsonObject.FLT) !== -1
        && (data.SDT == null ? "" : data.SDT).toLowerCase().indexOf(searchJsonObject.SDT) !== -1
        && (data.DES == null ? "" : data.DES).toLowerCase().indexOf(searchJsonObject.DES) !== -1
        && (data.STD == null ? "" : data.STD).toLowerCase().indexOf(searchJsonObject.STD) !== -1
        && (data.ETD == null ? "" : data.ETD).toLowerCase().indexOf(searchJsonObject.ETD) !== -1
        && (data.ATD == null ? "" : data.ATD).toLowerCase().indexOf(searchJsonObject.ATD) !== -1
        && (data.ATC == null ? "" : data.ATC).toLowerCase().indexOf(searchJsonObject.ATC) !== -1
        && (data.GAT == null ? "" : data.GAT).toLowerCase().indexOf(searchJsonObject.GAT) !== -1
        && (data.GST == null ? "" : data.GST).toLowerCase().indexOf(searchJsonObject.GST) !== -1
        && (data.TAR == null ? "" : data.TAR).toLowerCase().indexOf(searchJsonObject.TAR) !== -1
        && (data.IR1 == null ? "" : data.IR1).toLowerCase().indexOf(searchJsonObject.IR1) !== -1
        && (data.TYP == null ? "" : data.TYP).toLowerCase().indexOf(searchJsonObject.TYP) !== -1
        && (data.SCH == null ? "" : data.SCH).toLowerCase().indexOf(searchJsonObject.SCH) !== -1
        && (data.ADV == null ? "" : data.ADV).toLowerCase().indexOf(searchJsonObject.ADV) !== -1
        && (data.REM == null ? "" : data.REM).toLowerCase().indexOf(searchJsonObject.REM) !== -1
        && (data.PBT == null ? "" : data.PBT).toLowerCase().indexOf(searchJsonObject.PBT) !== -1
        && (data.LKF == null ? "" : data.LKF).toLowerCase().indexOf(searchJsonObject.LKF) !== -1
        && (data.TOR == null ? "" : data.TOR).toLowerCase().indexOf(searchJsonObject.TOR) !== -1
        && (data.MIS == null ? "" : data.MIS).toLowerCase().indexOf(searchJsonObject.MIS) !== -1
        && (data.ABF == null ? "" : data.ABF).toLowerCase().indexOf(searchJsonObject.ABF) !== -1
        && (data.ABT == null ? "" : data.ABT).toLowerCase().indexOf(searchJsonObject.ABT) !== -1
        && (data.AD1 == null ? "" : data.AD1).toLowerCase().indexOf(searchJsonObject.AD1) !== -1
        && (data.AD2 == null ? "" : data.AD2).toLowerCase().indexOf(searchJsonObject.AD2) !== -1
        && (data.AD3 == null ? "" : data.AD3).toLowerCase().indexOf(searchJsonObject.AD3) !== -1
        && (data.ADC == null ? "" : data.ADC).toLowerCase().indexOf(searchJsonObject.ADC) !== -1
        && (data.AEF == null ? "" : data.AEF).toLowerCase().indexOf(searchJsonObject.AEF) !== -1
        && (data.AOT == null ? "" : data.AOT).toLowerCase().indexOf(searchJsonObject.AOT) !== -1
        && (data.ASB == null ? "" : data.ASB).toLowerCase().indexOf(searchJsonObject.ASB) !== -1
        && (data.ASS == null ? "" : data.ASS).toLowerCase().indexOf(searchJsonObject.ASS) !== -1
        && (data.BTT == null ? "" : data.BTT).toLowerCase().indexOf(searchJsonObject.BTT) !== -1
        && (data.CIR == null ? "" : data.CIR).toLowerCase().indexOf(searchJsonObject.CIR) !== -1
        && (data.CLE == null ? "" : data.CLE).toLowerCase().indexOf(searchJsonObject.CLE) !== -1
        && (data.PAX == null ? "" : data.PAX).toLowerCase().indexOf(searchJsonObject.PAX) !== -1
        && (data.PSC == null ? "" : data.PSC).toLowerCase().indexOf(searchJsonObject.PSC) !== -1
        && (data.MGT == null ? "" : data.MGT).toLowerCase().indexOf(searchJsonObject.MGT) !== -1
        && (data.MID == null ? "" : data.MID).toLowerCase().indexOf(searchJsonObject.MID) !== -1
        && (data.LMF == null ? "" : data.LMF).toLowerCase().indexOf(searchJsonObject.LMF) !== -1
        && (data.PCB == null ? "" : data.PCB).toLowerCase().indexOf(searchJsonObject.PCB) !== -1
        && (data.SED == null ? "" : data.SED).toLowerCase().indexOf(searchJsonObject.SED) !== -1

    }
    return filterFunction;
  }

  applyFilter(filterValue: string) {
    //console.log('apply filter');
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  // @HostListener('window:scroll', ['$event'])
  // onscroll(event) {
  //   const elem = event.currentTarget;
  //   console.log(elem.innerHeight);
  //   console.log(elem.pageYOffset);
  //   console.log(document.body.offsetHeight);
  //   console.log(this.pageLength);
  //   console.log(this.dataLength);

  //   if ((elem.innerHeight + elem.pageYOffset + 200) >= document.body.offsetHeight && this.pageLength <= this.dataLength) {

  //     this.pageLength += 30;
  //     this.paginator._changePageSize(this.pageLength);
  //   }
  // }
  //#endregion  

  //#region other functions  
  setDisplayedColumns(col: string): void {
    // let element = document.getElementById(col);
    if (this.displayedColumns.indexOf(col) < 0) {//show column       
      //element.className = 'showcol';
      //this.displayedColumns.splice(this.actualColumns.indexOf(col), 0, col);     
      this.columnArrayLength = this.displayedColumns.length;
      if (this.columnArrayLength === 1) {
        this.displayedColumns.splice(1, 0, col);
      }
      for (let i = 0; i < this.columnArrayLength; i++) {
        if (i === this.columnArrayLength - 1 && this.displayedColumns.indexOf(col) < 0) {
          this.displayedColumns.splice(this.columnArrayLength, 0, col); break;
        }
        else if ((this.actualColumns.indexOf(col) > this.actualColumns.indexOf(this.displayedColumns[i])) &&
          (this.actualColumns.indexOf(col) < this.actualColumns.indexOf(this.displayedColumns[i + 1]))) {
          this.displayedColumns.splice(i + 1, 0, col); break;
        }
        else {
        }
      }
    }
    else {//hide column      
      //element.className = 'hidecol';
      this.displayedColumns.forEach((item, index) => {
        if (item === col) this.displayedColumns.splice(index, 1);
      });

    }

  }
  setDisplayedFilters(col: string): void {
    col = col + '-filter';
    if (this.displayedFilters.indexOf(col) < 0) {//show filter 
      this.filterArrayLength = this.displayedFilters.length;
      if (this.filterArrayLength === 1) {
        this.displayedFilters.splice(1, 0, col);
      }
      for (let i = 0; i < this.filterArrayLength; i++) {
        if (i === this.filterArrayLength - 1 && this.displayedFilters.indexOf(col) < 0) {
          this.displayedFilters.splice(this.filterArrayLength, 0, col); break;
        }
        else if ((this.actualFilters.indexOf(col) > this.actualFilters.indexOf(this.displayedFilters[i])) &&
          (this.actualFilters.indexOf(col) < this.actualFilters.indexOf(this.displayedFilters[i + 1]))) {
          this.displayedFilters.splice(i + 1, 0, col); break;
        }
        else {
        }
      }
    }
    else {//hide filter 
      this.displayedFilters.forEach((item, index) => {
        if (item === col) this.displayedFilters.splice(index, 1);
      });

    }

  }

  toggleColumnsAndFilters(col: string) {
    this.setDisplayedColumns(col);
    this.setDisplayedFilters(col);
  }

  highlight(row) {
    if (this.selectedRowKey == row.FLK)
      this.selectedRowKey = '';
    else
      this.selectedRowKey = row.FLK;
  }

  getDateDifferenceInMinutes(earlierDate, laterDate) {
    var diff = (laterDate.getTime() - earlierDate.getTime()) / 1000;
    diff /= 60;
    return Math.abs(Math.round(diff));
  }

  convertUtcDate(date: Date) {
    //console.log(date);
    let convertedDate = new Date(new Date(date).getTime() + (new Date(date).getTimezoneOffset() / 60) * 60 * 60 * 1000);
    //console.log(convertedDate);
    return date;
  }

  //#endregion

  dragStarted(event: CdkDragStart, index: number) {
    this.previousIndex = index;
  }

  dropListDropped(event: CdkDropList, index: number) {
    if (event) {
      moveItemInArray(this.displayedColumns, this.previousIndex, index);
      moveItemInArray(this.displayedFilters, this.previousIndex, index);
    }
  }


}
