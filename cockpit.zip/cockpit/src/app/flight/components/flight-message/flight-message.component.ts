import { Component, OnInit } from '@angular/core';
import { FlightService } from 'src/app/core/services/flight.service';
import { FlightMessage } from '../../models/flight-message.model';

@Component({
  selector: 'flymon-flight-message',
  templateUrl: './flight-message.component.html',
  styleUrls: ['./flight-message.component.css']
})
export class FlightMessageComponent implements OnInit {

  flightMessages: FlightMessage[];  

  constructor(private fltService: FlightService) {
    
  }

  ngOnInit() {
  }

}
