import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightMessageComponent } from './flight-message.component';

describe('FlightMessageComponent', () => {
  let component: FlightMessageComponent;
  let fixture: ComponentFixture<FlightMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
