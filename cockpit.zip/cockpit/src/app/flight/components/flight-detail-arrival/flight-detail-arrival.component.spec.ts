import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightDetailArrivalComponent } from './flight-detail-arrival.component';

describe('FlightDetailArrivalComponent', () => {
  let component: FlightDetailArrivalComponent;
  let fixture: ComponentFixture<FlightDetailArrivalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightDetailArrivalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightDetailArrivalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
