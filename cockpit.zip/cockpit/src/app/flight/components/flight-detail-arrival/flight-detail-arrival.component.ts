import { Component, OnInit } from '@angular/core';
import { FlymonFlight } from '../../models/flymon-flight.model';
import { FlightService } from 'src/app/core/services/flight.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'flymon-flight-detail-arrival',
  templateUrl: './flight-detail-arrival.component.html',
  styleUrls: ['./flight-detail-arrival.component.css']
})
export class FlightDetailArrivalComponent implements OnInit {

  flightDetails: FlymonFlight;
  key: string;
  station: string;
  type: string = 'arrival';
  activeMobileTab: any = "flight";
  arrDisplayFlightPanel: boolean = true;
  greatestTime: string = 'STA';
  today = new Date();
  hyphen: string = '-';

  constructor(private flightService: FlightService, private route: ActivatedRoute, private router: Router, ) {

  }

  ngOnInit() {
    //set url params   
    this.route.params.subscribe(params => {
      if (params['station'])
        this.station = params['station']
    });
    //set query params
    this.route.queryParams.subscribe(params => {
      if (params.key)
        this.key = params.key
      this.getFlightDetails(this.key, this.station, this.type);  //get flight details
    });

  }

  getFlightDetails(key: string, station: string, arrOrDep: string) {  //get flight details from flight key

    this.flightService.getFlightDetails(key, station, arrOrDep).subscribe(
      data => {
        this.flightDetails = data;
        // console.log('flight details received from api: ' + JSON.stringify(this.flightDetails));        
      })
  }

  goBack() {
    window.history.back();
  }

  onDisplayFlightPanel() {
    this.arrDisplayFlightPanel = !this.arrDisplayFlightPanel;

  }


  onMobileTabClick(activeTabParam) {
    this.activeMobileTab = activeTabParam;
    let element = document.getElementById(activeTabParam);
    element.scrollIntoView();
    var header = 48;    //for fixed header
    var scrolledY = window.scrollY;
    if (scrolledY)
      window.scroll(0, scrolledY - header);
  }

}
