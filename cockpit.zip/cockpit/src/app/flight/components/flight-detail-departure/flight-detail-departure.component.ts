import { Component, OnInit, Input } from '@angular/core';
import { FlightService } from 'src/app/core/services/flight.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FlymonFlight } from '../../models/flymon-flight.model';


@Component({
  selector: 'flymon-flight-detail',
  templateUrl: './flight-detail-departure.component.html',
  styleUrls: ['./flight-detail-departure.component.css']
})
export class FlightDetailDepartureComponent implements OnInit {
  flightDetails: FlymonFlight;
  key: string;
  station: string;
  type: string = 'departure';
  activeMobileTab: any = "flight";
  depDisplayFlightPanel: boolean = true;
  greatestTime: string = 'ATD';
  hyphen: string = '-';
  today = new Date();

  constructor(private flightService: FlightService, private route: ActivatedRoute, private router: Router, ) {

  }

  ngOnInit() {
    //set url params   
    this.route.params.subscribe(params => {
      if (params['station'])
        this.station = params['station']
    });
    //set query params
    this.route.queryParams.subscribe(params => {
      if (params.key)
        this.key = params.key
      this.getFlightDetails(this.key, this.station, this.type);  //get flight details
    });
  }

  getFlightDetails(key: string, station: string, arrOrDep: string) {  //get flight details from flight key

    this.flightService.getFlightDetails(key, station, arrOrDep).subscribe(
      data => {
        this.flightDetails = data;
        //console.log('flight details received from api: ' + JSON.stringify(this.flightDetails));    
      })
  }

  goBack() {
    window.history.back();
  }

  onDisplayFlightPanel() {
    this.depDisplayFlightPanel = !this.depDisplayFlightPanel;

  }

  onMobileTabClick(activeTabParam) {
    this.activeMobileTab = activeTabParam;
    let element = document.getElementById(activeTabParam);
    element.scrollIntoView();
    var header = 48;    //for fixed header
    var scrolledY = window.scrollY;
    if (scrolledY)
      window.scroll(0, scrolledY - header);
  }

}
