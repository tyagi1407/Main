import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightDetailDepartureComponent } from './flight-detail-departure.component';

describe('FlightDetailComponent', () => {
  let component: FlightDetailDepartureComponent;
  let fixture: ComponentFixture<FlightDetailDepartureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightDetailDepartureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightDetailDepartureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
