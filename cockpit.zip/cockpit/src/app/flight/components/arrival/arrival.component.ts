import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { FormControl } from '@angular/forms';
import { FlightService } from './../../../core/services/flight.service'
import { FlightMockService } from './../../../core/mocks/flight-mock.service';
import { Flight } from '../../models/flight.model';
import { environment } from 'src/environments/environment';
import { ExportAsService, ExportAsConfig } from 'ngx-export-as';
import { PrintService } from './../../../core/services/print.service';
import { interval, combineLatest } from 'rxjs';
import { map } from 'rxjs/operators';
import { FlymonFlight } from '../../models/flymon-flight.model';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { CdkDragStart, CdkDropList, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
  selector: 'flymon-arrival',
  templateUrl: './arrival.component.html',
  styleUrls: ['./arrival.component.css']
})
export class ArrivalComponent implements OnInit {
  //variables
  arrColumnArrayLength: number;
  arrFilterArrayLength: number;
  showArrival: boolean = false;
  showArrDwnloadIcons: boolean = false;
  showArrClmSlctPanel: boolean = false;
  arrFileName: string = "FlymonArrFlt";
  totalArrival: number;
  arrFlightArray: Flight[] = [];
  arrFlymonFlightArray: FlymonFlight[];
  mock: boolean = environment.mock;
  arrStation: string = 'ZRH'; //default station
  hour = 3;
  arrFrom = new Date(Date.now() - this.hour * 60 * 60 * 1000).toISOString();
  arrTo = new Date(Date.now() + this.hour * 60 * 60 * 1000).toISOString();
  // arrFrom: string;
  // arrTo: string;
  selectedRowKey: string;
  now = new Date();
  //lastApiCallTime: Date;
  loader: boolean = true;
  previousIndex: number;
  @Input() public arrFilterJson: string;
  //file export configurations
  exportAsConfigPdf: ExportAsConfig = { type: 'pdf', elementId: 'arrExport', options: { orientation: 'landscape', margins: { top: '20' }, } }
  exportAsConfigCsv: ExportAsConfig = { type: 'csv', elementId: 'arrExport' }
  exportAsConfigExcel: ExportAsConfig = { type: 'xlsx', elementId: 'arrExport' }
  //material variables
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  //#region form controls
  flkFilter = new FormControl('');
  //flcFilter = new FormControl('');
  fltFilter = new FormControl('');
  orgFilter = new FormControl('');
  staFilter = new FormControl('');
  ataFilter = new FormControl('');
  etaFilter = new FormControl('');
  gatFilter = new FormControl('');
  tarFilter = new FormControl('');
  remFilter = new FormControl('');
  paxFilter = new FormControl('');
  lkfFilter = new FormControl('');
  sdtFilter = new FormControl('');
  delFilter = new FormControl('');
  ir1Filter = new FormControl('');
  typFilter = new FormControl('');
  schFilter = new FormControl('');
  LTDFilter = new FormControl('');
  MISFilter = new FormControl('');
  ADVFilter = new FormControl('');
  TORFilter = new FormControl('');
  LTAFilter = new FormControl('');
  VI1Filter = new FormControl('');
  VI2Filter = new FormControl('');
  TERFilter = new FormControl('');
  TDTFilter = new FormControl('');
  STPFilter = new FormControl('');
  MSAFilter = new FormControl('');
  MIAFilter = new FormControl('');
  LKRFilter = new FormControl('');
  FCDFilter = new FormControl('');
  FCCFilter = new FormControl('');
  EDPFilter = new FormControl('');
  PCBFilter = new FormControl('');
  PSCFilter = new FormControl('');
  //#endregion
  public actualArrColumns: string[] = ['FLT', 'ORG', 'SDT', 'STA', 'ETA', 'ATA', 'DEL', 'GAT', 'TAR', 'IR1', 'TYP', 'SCH', 'REM', 'PAX', 'LKF', 'LTD', 'MIS', 'ADV', 'TOR', 'LTA', 'VI1', 'VI2', 'TER', 'TDT', 'STP', 'MSA', 'MIA', 'LKR', 'FCD', 'FCC', 'EDP', 'DEL', 'PAX', 'PCB	', 'PSC'];
  public displayedArrColumns: string[];// = ['FLT', 'ORG', 'SDT', 'STA', 'ETA', 'ATA', 'DEL', 'TAR', 'IR1', 'TYP', 'SCH', 'REM', 'PAX', 'LKF'];
  public actualArrFilters: string[] = ['FLT-filter', 'ORG-filter', 'SDT-filter', 'STA-filter', 'ETA-filter', 'ATA-filter', 'DEL-filter', 'GAT-filter', 'TAR-filter', 'IR1-filter', 'TYP-filter', 'SCH-filter', 'REM-filter', 'PAX-filter', 'LKF-filter', 'LTD-filter', 'MIS-filter', 'ADV-filter', 'TOR-filter', 'LTA-filter', 'VI1-filter', 'VI2-filter', 'TER-filter', 'TDT-filter', 'STP-filter', 'MSA-filter', 'MIA-filter', 'LKR-filter', 'FCD-filter', 'FCC-filter', 'EDP-filter', 'PCB-filter', 'PSC-filter'];
  public displayedArrFilters: string[];// =['FLT-filter', 'ORG-filter', 'SDT-filter', 'STA-filter', 'ETA-filter', 'ATA-filter', 'DEL-filter', 'TAR-filter', 'IR1-filter', 'TYP-filter', 'SCH-filter', 'REM-filter', 'PAX-filter', 'LKF-filter']
  public arrDataSource = new MatTableDataSource<Flight>();
  arrFilterValues = { FLT: '', ORG: '', SDT: '', STA: '', ETA: '', ATA: '', DEL: '', GAT: '', TAR: '', IR1: '', TYP: '', SCH: '', REM: '', PAX: '', LKF: '', LTD: '', MIS: '', ADV: '', TOR: '', LTA: '', VI1: '', VI2: '', TER: '', TDT: '', STP: '', MSA: '', MIA: '', LKR: '', FCD: '', FCC: '', EDP: '', PCB: '', PSC: '' };


  constructor(private route: ActivatedRoute, private router: Router, private printService: PrintService, private exportAsService: ExportAsService,
    private flightService: FlightService, private flightMockService: FlightMockService, private datePipe: DatePipe) {

  }

  ngOnInit() {
    //set url params
    combineLatest(this.route.params, this.route.queryParams)
      .pipe(map(results => ({ params: results[0].station, queryParams: results[1] })))
      .subscribe(results => {
        var stn = results.params;
        this.arrStation = stn.toUpperCase();
        if (results.queryParams.from || results.queryParams.to) {
          this.setFilterParameters(results.queryParams);
        }
        //if (this.router.url.toLowerCase().toString().indexOf('profile') ==-1)
        this.getArrivalFlightData(true);    //get data on search parameters selection  
      });

    if (this.mock) {
      this.arrFlightArray = this.flightMockService.getFlights();//TODO:change mock array to receive new format
      this.totalArrival = this.arrFlightArray.length;
      this.arrDataSource.data = this.arrFlightArray;
      this.arrDataSource.filterPredicate = this.createArrFilter();
    }
    else {
      var t = interval(30000);    //get data on specific interval
      t.subscribe(val => {
        if (this.router.url.toLowerCase().toString().indexOf('create-profile') == -1)
          this.getArrivalFlightData();
      }
      );
    }
    //#region material events    
    this.arrDataSource.paginator = this.paginator;
    this.arrDataSource.sort = this.sort;
    this.fltFilter.valueChanges.subscribe(x => { this.arrFilterValues.FLT = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.orgFilter.valueChanges.subscribe(x => { this.arrFilterValues.ORG = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.sdtFilter.valueChanges.subscribe(x => { this.arrFilterValues.SDT = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.staFilter.valueChanges.subscribe(x => { this.arrFilterValues.STA = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.etaFilter.valueChanges.subscribe(x => { this.arrFilterValues.ETA = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.ataFilter.valueChanges.subscribe(x => { this.arrFilterValues.ATA = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.delFilter.valueChanges.subscribe(x => { this.arrFilterValues.DEL = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.gatFilter.valueChanges.subscribe(x => { this.arrFilterValues.GAT = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.tarFilter.valueChanges.subscribe(x => { this.arrFilterValues.TAR = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.ir1Filter.valueChanges.subscribe(x => { this.arrFilterValues.IR1 = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.typFilter.valueChanges.subscribe(x => { this.arrFilterValues.TYP = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.schFilter.valueChanges.subscribe(x => { this.arrFilterValues.SCH = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.remFilter.valueChanges.subscribe(x => { this.arrFilterValues.REM = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.paxFilter.valueChanges.subscribe(x => { this.arrFilterValues.PAX = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.lkfFilter.valueChanges.subscribe(x => { this.arrFilterValues.LKF = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.LTDFilter.valueChanges.subscribe(x => { this.arrFilterValues.LTD = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.MISFilter.valueChanges.subscribe(x => { this.arrFilterValues.MIS = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    //this.ADVFilter.valueChanges.subscribe(x => { this.arrFilterValues.ADV = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.TORFilter.valueChanges.subscribe(x => { this.arrFilterValues.TOR = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.LTAFilter.valueChanges.subscribe(x => { this.arrFilterValues.LTA = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.VI1Filter.valueChanges.subscribe(x => { this.arrFilterValues.VI1 = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.VI2Filter.valueChanges.subscribe(x => { this.arrFilterValues.VI2 = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.TERFilter.valueChanges.subscribe(x => { this.arrFilterValues.TER = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.TDTFilter.valueChanges.subscribe(x => { this.arrFilterValues.TDT = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.STPFilter.valueChanges.subscribe(x => { this.arrFilterValues.STP = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.MSAFilter.valueChanges.subscribe(x => { this.arrFilterValues.MSA = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.MIAFilter.valueChanges.subscribe(x => { this.arrFilterValues.MIA = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    //this.LKRFilter.valueChanges.subscribe(x => { this.arrFilterValues.LKR = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.FCDFilter.valueChanges.subscribe(x => { this.arrFilterValues.FCD = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.FCCFilter.valueChanges.subscribe(x => { this.arrFilterValues.FCC = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.EDPFilter.valueChanges.subscribe(x => { this.arrFilterValues.EDP = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.PCBFilter.valueChanges.subscribe(x => { this.arrFilterValues.PCB = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });
    this.PSCFilter.valueChanges.subscribe(x => { this.arrFilterValues.PSC = x; this.arrFilterJson = JSON.stringify(this.arrFilterValues); this.arrDataSource.filter = JSON.stringify(this.arrFilterValues); });

    //#endregion  


  }

  setFilterParameters(params: Params) {//set filters
    //console.log(params);    
    if (params.from)
      this.arrFrom = params.from
    if (params.to)
      this.arrTo = params.to;
  }

  getArrivalFlightData(firstLoad: boolean = false) {//get arrival flight data based on parameters
    this.loader = true;
    this.flightService.getFlightsFromStation(this.arrStation, 'arrival', this.arrFrom, this.arrTo).subscribe(
      data => {
        this.arrFlymonFlightArray = data;
        this.transformArrFlightArray(firstLoad);
        //this.lastApiCallTime = new Date();
        this.loader = false;
      },
      res => {
        if (res) {
          if (res.status !== 200) {  //TODO: what to do?
            this.arrFlymonFlightArray = [];
            this.transformArrFlightArray(firstLoad);
            this.loader = false;
            //console.log(res.message);
          }
        }
      }
      //err => console.error('error received: ' + err)
    )

  }

  transformArrFlightArray(firstLoad: boolean = false) {
    //console.log('arrival data received from api: ' + JSON.stringify(this.arrFlymonFlightArray));
    this.arrFlightArray = [];
    this.arrFlymonFlightArray.forEach((item) => {
      if (item) {
        this.arrFlightArray.push({
          FLK: item.FLK,
          FLT: item.FLC + item.FLN.toString(),
          FLN: item.FLN.toString(),
          FLC: item.FLC,
          ORG: item.ORG,
          DES: item.DES,
          SDT: this.datePipe.transform(item.arrivalTimes.STA, 'yy/MM/dd') == null ? "" : this.datePipe.transform(item.arrivalTimes.STA, 'yy/MM/dd').toString(),
          STA: this.datePipe.transform(item.arrivalTimes.STA, 'HH:mm') == null ? "" : this.datePipe.transform(item.arrivalTimes.STA, 'HH:mm').toString(),
          ETA: this.datePipe.transform(item.arrivalTimes.ETA, 'HH:mm') == null ? "" : this.datePipe.transform(item.arrivalTimes.ETA, 'HH:mm').toString(),
          ATA: this.datePipe.transform(item.arrivalTimes.ATA, 'HH:mm') == null ? "" : this.datePipe.transform(item.arrivalTimes.ATA, 'HH:mm').toString(),
          DEL: "",//TODO: to be created in db
          TAR: item.arrivalAirports.TAR,
          IR1: item.arrivalDelays == null ? "" : item.arrivalDelays.IR1,
          TYP: item.arrivalAircrafts == null ? "" : item.arrivalAircrafts.TYP,
          SCH: item.DMI,
          REM: item.REM,
          PAX: item.arrivalPassengers.PAX == null ? "" : item.arrivalPassengers.PAX.toString(),
          LKF: item.arrivalLinkAndShare.LKF,
          //UPD: new Date(this.datePipe.transform(item.SDM, 'E, d MMM yyyy HH:mm:ss Z').toString()) > this.lastApiCallTime ? '1' : '0',
          UPD: this.getDateDifferenceInMinutes(new Date(this.datePipe.transform(item.SDM, 'E, d MMM yyyy HH:mm:ss Z').toString()), new Date()) <= 5 ? '1' : '0',
          LTD: "-",
          MIS: item.MIS,
          TOR: item.arrivalAircrafts.TOR,
          LTA: "-",
          VI1: "-",
          VI2: "-",
          TER: item.arrivalAirports.TER,
          TDT: "-",
          STP: this.datePipe.transform(item.arrivalTimes.STP, 'HH:mm') == null ? "" : this.datePipe.transform(item.arrivalTimes.STP, 'HH:mm').toString(),
          MSA: item.MSA,
          MIA: item.MIA,
          LKR: item.arrivalLinkAndShare.LKR,
          FCD: this.datePipe.transform(item.arrivalTimes.FCD, 'HH:mm') == null ? "" : this.datePipe.transform(item.arrivalTimes.FCD, 'HH:mm').toString(),
          FCC: item.FCC,
          EDP: this.datePipe.transform(item.arrivalRoutes.EDP, 'HH:mm') == null ? "" : this.datePipe.transform(item.arrivalRoutes.EDP, 'HH:mm').toString(),
          PCB: "-",
          PSC: item.arrivalAircrafts.PSC,
          //departure fields empty
          GAT: item.arrivalAirports.GAT,
          GST: "",
          STD: "",
          ETD: "",
          ATD: "",
          ADV: "",
          PBT: "",
          ATC: "",
          ABF: "",
          ABT: "",
          AD1: "",
          AD2: "",
          AD3: "",
          ADC: "",
          AEF: "",
          AOT: "",
          ASB: "",
          ASS: "",
          BTT: "",
          CIR: "",
          CLE: "",
          MGT: "",
          MID: "",
          LMF: "",
          SED: ""
        });
      }
    });
    //console.log('arrival data after mapping: ' + JSON.stringify(this.arrFlightArray));
    this.totalArrival = this.arrFlightArray.length;
    this.arrDataSource.data = this.arrFlightArray;
    if (firstLoad) {
      this.arrDataSource.filterPredicate = this.createMultivalueArrFilter();
      //console.log(this.arrFilterJson);
      if (this.arrFilterJson.length > 0) {
        this.arrDataSource.filter = this.arrFilterJson;//TODO:check if required on first load?
        this.displayedArrColumns = this.flightService.getPropertyNamesFromJson(this.arrFilterJson);
      }
      else {
        //default columns if error received from profile api 
        this.displayedArrColumns = ['FLT', 'ORG', 'SDT', 'STA', 'ETA', 'ATA', 'DEL', 'GAT', 'TAR', 'IR1', 'TYP', 'SCH', 'REM', 'PAX', 'LKF'];
      }

      this.displayedArrFilters = this.displayedArrColumns.map(item => item + '-filter');
      //console.log(this.displayedArrColumns);
      //console.log(this.displayedArrFilters);
    }


  }

  //#region file export functions  
  exportArrPdf() { this.exportAsService.save(this.exportAsConfigPdf, this.arrFileName + new Date().toISOString().slice(0, 10)); }
  exportArrCsv() { this.exportAsService.save(this.exportAsConfigCsv, this.arrFileName + new Date().toISOString().slice(0, 10)); }
  exportArrExcel() { this.exportAsService.save(this.exportAsConfigExcel, this.arrFileName + new Date().toISOString().slice(0, 10)); }
  //#endregion

  //#region print function 
  printArrival(htmlSectionId: string) {
    this.printService.print(htmlSectionId, 'AFIS ARRIVAL');
  }
  //#endregion

  //#region material functions
  //create multivalue filter
  createMultivalueArrFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {
      //console.log(filter);
      let searchJsonObject = JSON.parse(filter);
      //currently FLT,ORG,DES,GAT,TAR,SCH columns have multivalue filter options, this can be extended if required
      let fltSearch: string[] = searchJsonObject.FLT ? searchJsonObject.FLT.split(',') : [""];
      var fltRegex = new RegExp(fltSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));
      let orgSearch: string[] = searchJsonObject.ORG ? searchJsonObject.ORG.split(',') : [""];
      var orgRegex = new RegExp(orgSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));
      let gatSearch: string[] = searchJsonObject.GAT ? searchJsonObject.GAT.split(',') : [""];
      var gatRegex = new RegExp(gatSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));
      let tarSearch: string[] = searchJsonObject.TAR ? searchJsonObject.TAR.split(',') : [""];
      var tarRegex = new RegExp(tarSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));
      let schSearch: string[] = searchJsonObject.SCH ? searchJsonObject.SCH.split(',') : [""];
      var schRegex = new RegExp(schSearch.map(function (s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') }).join('|'));

      return fltRegex.test((data.FLT == null ? "" : data.FLT).toLowerCase())
        && orgRegex.test((data.ORG == null ? "" : data.ORG).toLowerCase())
        && gatRegex.test((data.GAT == null ? "" : data.GAT).toLowerCase())
        && tarRegex.test((data.TAR == null ? "" : data.TAR).toLowerCase())
        && schRegex.test((data.SCH == null ? "" : data.SCH).toLowerCase())
        // && (data.ORG == null ? "" : data.ORG).toLowerCase().indexOf(searchJsonObject.ORG) !== -1
        && (data.SDT == null ? "" : data.SDT).toLowerCase().indexOf(searchJsonObject.SDT ? searchJsonObject.SDT : "") !== -1
        && (data.STA == null ? "" : data.STA).toLowerCase().indexOf(searchJsonObject.STA ? searchJsonObject.STA : "") !== -1
        && (data.ETA == null ? "" : data.ETA).toLowerCase().indexOf(searchJsonObject.ETA ? searchJsonObject.ETA : "") !== -1
        && (data.ATA == null ? "" : data.ATA).toLowerCase().indexOf(searchJsonObject.ATA ? searchJsonObject.ATA : "") !== -1
        && (data.DEL == null ? "" : data.DEL).toLowerCase().indexOf(searchJsonObject.DEL ? searchJsonObject.DEL : "") !== -1
        //&& (data.TAR == null ? "" : data.TAR).toLowerCase().indexOf(searchJsonObject.TAR) !== -1
        && (data.IR1 == null ? "" : data.IR1).toLowerCase().indexOf(searchJsonObject.IR1 ? searchJsonObject.IR1 : "") !== -1
        && (data.TYP == null ? "" : data.TYP).toLowerCase().indexOf(searchJsonObject.TYP ? searchJsonObject.TYP : "") !== -1
        //&& (data.SCH == null ? "" : data.SCH).toLowerCase().indexOf(searchJsonObject.SCH) !== -1
        && (data.REM == null ? "" : data.REM).toLowerCase().indexOf(searchJsonObject.REM ? searchJsonObject.REM : "") !== -1
        && (data.PAX == null ? "" : data.PAX).toLowerCase().indexOf(searchJsonObject.PAX ? searchJsonObject.PAX : "") !== -1
        && (data.LKF == null ? "" : data.LKF).toLowerCase().indexOf(searchJsonObject.LKF ? searchJsonObject.LKF : "") !== -1
        && (data.LTD == null ? "" : data.LTD).toLowerCase().indexOf(searchJsonObject.LTD ? searchJsonObject.LTD : "") !== -1
        && (data.MIS == null ? "" : data.MIS).toLowerCase().indexOf(searchJsonObject.MIS ? searchJsonObject.MIS : "") !== -1
        //&& (data.ADV == null ? "" : data.ADV).toLowerCase().indexOf(searchJsonObject.ADV) !== -1
        && (data.TOR == null ? "" : data.TOR).toLowerCase().indexOf(searchJsonObject.TOR ? searchJsonObject.TOR : "") !== -1
        && (data.LTA == null ? "" : data.LTA).toLowerCase().indexOf(searchJsonObject.LTA ? searchJsonObject.LTA : "") !== -1
        && (data.VI1 == null ? "" : data.VI1).toLowerCase().indexOf(searchJsonObject.VI1 ? searchJsonObject.VI1 : "") !== -1
        && (data.VI2 == null ? "" : data.VI2).toLowerCase().indexOf(searchJsonObject.VI2 ? searchJsonObject.VI2 : "") !== -1
        && (data.TER == null ? "" : data.TER).toLowerCase().indexOf(searchJsonObject.TER ? searchJsonObject.TER : "") !== -1
        && (data.TDT == null ? "" : data.TDT).toLowerCase().indexOf(searchJsonObject.TDT ? searchJsonObject.TDT : "") !== -1
        && (data.STP == null ? "" : data.STP).toLowerCase().indexOf(searchJsonObject.STP ? searchJsonObject.STP : "") !== -1
        && (data.MSA == null ? "" : data.MSA).toLowerCase().indexOf(searchJsonObject.MSA ? searchJsonObject.MSA : "") !== -1
        && (data.MIA == null ? "" : data.MIA).toLowerCase().indexOf(searchJsonObject.MIA ? searchJsonObject.MIA : "") !== -1
        //&& (data.LKR == null ? "" : data.LKR).toLowerCase().indexOf(searchJsonObject.LKR ? searchJsonObject.LKR : "") !== -1
        && (data.FCD == null ? "" : data.FCD).toLowerCase().indexOf(searchJsonObject.FCD ? searchJsonObject.FCD : "") !== -1
        && (data.FCC == null ? "" : data.FCC).toLowerCase().indexOf(searchJsonObject.FCC ? searchJsonObject.FCC : "") !== -1
        && (data.EDP == null ? "" : data.EDP).toLowerCase().indexOf(searchJsonObject.EDP ? searchJsonObject.EDP : "") !== -1
        && (data.PCB == null ? "" : data.PCB).toLowerCase().indexOf(searchJsonObject.PCB ? searchJsonObject.PCB : "") !== -1
        && (data.PSC == null ? "" : data.PSC).toLowerCase().indexOf(searchJsonObject.PSC ? searchJsonObject.PSC : "") !== -1
    }
    return filterFunction;
  }
  //simple filter
  createArrFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {

      let searchJsonObject = JSON.parse(filter);
      return (data.FLT == null ? "" : data.FLT).toLowerCase().indexOf(searchJsonObject.FLT) !== -1
        && (data.ORG == null ? "" : data.ORG).toLowerCase().indexOf(searchJsonObject.ORG) !== -1
        && (data.SDT == null ? "" : data.SDT).toLowerCase().indexOf(searchJsonObject.SDT) !== -1
        && (data.STA == null ? "" : data.STA).toLowerCase().indexOf(searchJsonObject.STA) !== -1
        && (data.ETA == null ? "" : data.ETA).toLowerCase().indexOf(searchJsonObject.ETA) !== -1
        && (data.ATA == null ? "" : data.ATA).toLowerCase().indexOf(searchJsonObject.ATA) !== -1
        && (data.DEL == null ? "" : data.DEL).toLowerCase().indexOf(searchJsonObject.DEL) !== -1
        && (data.TAR == null ? "" : data.TAR).toLowerCase().indexOf(searchJsonObject.TAR) !== -1
        && (data.IR1 == null ? "" : data.IR1).toLowerCase().indexOf(searchJsonObject.IR1) !== -1
        && (data.TYP == null ? "" : data.TYP).toLowerCase().indexOf(searchJsonObject.TYP) !== -1
        && (data.SCH == null ? "" : data.SCH).toLowerCase().indexOf(searchJsonObject.SCH) !== -1
        && (data.REM == null ? "" : data.REM).toLowerCase().indexOf(searchJsonObject.REM) !== -1
        && (data.PAX == null ? "" : data.PAX).toLowerCase().indexOf(searchJsonObject.PAX) !== -1
        && (data.LKF == null ? "" : data.LKF).toLowerCase().indexOf(searchJsonObject.LKF) !== -1
        && (data.LTD == null ? "" : data.LTD).toLowerCase().indexOf(searchJsonObject.LTD) !== -1
        && (data.MIS == null ? "" : data.MIS).toLowerCase().indexOf(searchJsonObject.MIS) !== -1
        //&& (data.ADV == null ? "" : data.ADV).toLowerCase().indexOf(searchJsonObject.ADV) !== -1
        && (data.TOR == null ? "" : data.TOR).toLowerCase().indexOf(searchJsonObject.TOR) !== -1
        && (data.LTA == null ? "" : data.LTA).toLowerCase().indexOf(searchJsonObject.LTA) !== -1
        && (data.VI1 == null ? "" : data.VI1).toLowerCase().indexOf(searchJsonObject.VI1) !== -1
        && (data.VI2 == null ? "" : data.VI2).toLowerCase().indexOf(searchJsonObject.VI2) !== -1
        && (data.TER == null ? "" : data.TER).toLowerCase().indexOf(searchJsonObject.TER) !== -1
        && (data.TDT == null ? "" : data.TDT).toLowerCase().indexOf(searchJsonObject.TDT) !== -1
        && (data.STP == null ? "" : data.STP).toLowerCase().indexOf(searchJsonObject.STP) !== -1
        && (data.MSA == null ? "" : data.MSA).toLowerCase().indexOf(searchJsonObject.MSA) !== -1
        && (data.MIA == null ? "" : data.MIA).toLowerCase().indexOf(searchJsonObject.MIA) !== -1
        && (data.LKR == null ? "" : data.LKR).toLowerCase().indexOf(searchJsonObject.LKR) !== -1
        && (data.FCD == null ? "" : data.FCD).toLowerCase().indexOf(searchJsonObject.FCD) !== -1
        && (data.FCC == null ? "" : data.FCC).toLowerCase().indexOf(searchJsonObject.FCC) !== -1
        && (data.EDP == null ? "" : data.EDP).toLowerCase().indexOf(searchJsonObject.EDP) !== -1
        && (data.PCB == null ? "" : data.PCB).toLowerCase().indexOf(searchJsonObject.PCB) !== -1
        && (data.PSC == null ? "" : data.PSC).toLowerCase().indexOf(searchJsonObject.PSC) !== -1
    }
    return filterFunction;
  }

  applyFilter(filterValue: string) {
    this.arrDataSource.filter = filterValue.trim().toLowerCase();
    if (this.arrDataSource.paginator) {
      this.arrDataSource.paginator.firstPage();
    }
  }
  //#endregion

  //#region other functions  

  setArrDisplayedColumns(col: string): void {
    // let element = document.getElementById(col);
    if (this.displayedArrColumns.indexOf(col) < 0) {//show column 
      this.arrColumnArrayLength = this.displayedArrColumns.length;
      if (this.arrColumnArrayLength === 1) {
        this.displayedArrColumns.splice(1, 0, col);
      }
      for (let i = 0; i < this.arrColumnArrayLength; i++) {
        if (i === this.arrColumnArrayLength - 1 && this.displayedArrColumns.indexOf(col) < 0) {
          this.displayedArrColumns.splice(this.arrColumnArrayLength, 0, col); break;
        }
        else if ((this.actualArrColumns.indexOf(col) > this.actualArrColumns.indexOf(this.displayedArrColumns[i])) &&
          (this.actualArrColumns.indexOf(col) < this.actualArrColumns.indexOf(this.displayedArrColumns[i + 1]))) {
          this.displayedArrColumns.splice(i + 1, 0, col); break;
        }
        else {
        }
      }
    }
    else {//hide column      
      //element.className = 'hidecol';
      this.displayedArrColumns.forEach((item, index) => {
        if (item === col) this.displayedArrColumns.splice(index, 1);
      });

    }

  }
  setArrDisplayedFilters(col: string): void {
    col = col + '-filter';
    if (this.displayedArrFilters.indexOf(col) < 0) {//show filter 
      this.arrFilterArrayLength = this.displayedArrFilters.length;
      if (this.arrFilterArrayLength === 1) {
        this.displayedArrFilters.splice(1, 0, col);
      }
      for (let i = 0; i < this.arrFilterArrayLength; i++) {
        if (i === this.arrFilterArrayLength - 1 && this.displayedArrFilters.indexOf(col) < 0) {
          this.displayedArrFilters.splice(this.arrFilterArrayLength, 0, col); break;
        }
        else if ((this.actualArrFilters.indexOf(col) > this.actualArrFilters.indexOf(this.displayedArrFilters[i])) &&
          (this.actualArrFilters.indexOf(col) < this.actualArrFilters.indexOf(this.displayedArrFilters[i + 1]))) {
          this.displayedArrFilters.splice(i + 1, 0, col); break;
        }
        else {
        }
      }
    }
    else {//hide filter 
      this.displayedArrFilters.forEach((item, index) => {
        if (item === col) this.displayedArrFilters.splice(index, 1);
      });

    }

  }

  toggleArrColumnsAndFilters(col: string) {
    this.setArrDisplayedColumns(col);
    this.setArrDisplayedFilters(col);
  }

  highlight(row) {
    if (this.selectedRowKey == row.FLK)
      this.selectedRowKey = '';
    else
      this.selectedRowKey = row.FLK;
    // let element = document.getElementById('break');
    // element.scrollIntoView();
  }

  getDateDifferenceInMinutes(earlierDate, laterDate) {
    var diff = (laterDate.getTime() - earlierDate.getTime()) / 1000;
    diff /= 60;
    return Math.abs(Math.round(diff));
  }


  //#endregion

  dragStarted(event: CdkDragStart, index: number) {
    this.previousIndex = index;
  }

  dropListDropped(event: CdkDropList, index: number) {
    if (event) {
      moveItemInArray(this.displayedArrColumns, this.previousIndex, index);
      moveItemInArray(this.displayedArrFilters, this.previousIndex, index);
    }
  }

}
