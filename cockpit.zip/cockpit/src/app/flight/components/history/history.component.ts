import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDatepickerInputEvent, MatPaginator, MatTableDataSource } from '@angular/material';
import { ExportAsConfig, ExportAsService } from 'ngx-export-as';
import { PrintService } from 'src/app/core/services/print.service';
import { FlightService } from 'src/app/core/services/flight.service';
import { FlightMockService } from 'src/app/core/mocks/flight-mock.service';
import { HistoryFlight, FlightDepartureData, FlightArrivalData } from '../../models/flight-history';

@Component({
  selector: 'flymon-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
  station: string;
  depOrArr: string = '1';
  hyphen: string = '-';
  showStationPanel: boolean = false;
  fromHour: number = 0;
  fromMinute: number = 0;
  toHour: number = 0;
  toMinute: number = 0;
  fromDay = 6;
  toDay = 0;
  histFileName: string = "FlymonHistFlt";
  dataSource = null;
  loader: boolean = true;
  selectedRowKey: string;

  //material variables
  @ViewChild(MatPaginator) paginator: MatPaginator;
  //minDate = new Date(Date.now() - this.day * 24 * 60 * 60 * 1000);
  maxDate = new Date(Date.now() + this.toDay * 24 * 60 * 60 * 1000);
  fromDate: Date = new Date(Date.now() - this.fromDay * 24 * 60 * 60 * 1000);
  toDate: Date = new Date(Date.now() - this.toDay * 24 * 60 * 60 * 1000);
  //file export configurations
  exportAsConfigPdf: ExportAsConfig = { type: 'pdf', elementId: 'arrival_tab', options: { orientation: 'landscape', margins: { top: '20' }, } }
  exportAsConfigCsv: ExportAsConfig = { type: 'csv', elementId: 'arrival_tab' }
  exportAsConfigExcel: ExportAsConfig = { type: 'xlsx', elementId: 'arrival_tab' }
  histFlights: HistoryFlight;

  displayedColumns: string[] = ['FLT', 'FLX', 'ORG', 'DES', 'STD', 'ETD', 'ATD', 'REG', 'TYP', 'TYS', 'GAT', 'TAR', 'LKF', 'CGO', 'DDL', 'MLA', 'ULC', 'IR1', 'IR2', 'IR3', 'IR4', 'DL1', 'DL2', 'DL3', 'DL4', 'IX1', 'IX2', 'IX3', 'IX4', 'REM'];

  constructor(private route: ActivatedRoute, private router: Router, private printService: PrintService, private exportAsService: ExportAsService,
    private flightService: FlightService, private flightMockService: FlightMockService) {

  }

  ngOnInit() {

    this.route.params.subscribe(params => {
      if (params['station']) {
        var stn = params['station'];
        this.station = stn.toUpperCase();
      }
      this.getHistoryData(this.station, this.fromDate.toISOString(), this.toDate.toISOString());  //get flight details
    });
  }

  //functions
  getHistoryData(station: string, fromDate: string, toDate: string) {
    this.loader = true;
    console.log(this.loader);
    this.flightService.getHistoricalFlightDetails(this.station, this.fromDate.toISOString(), this.toDate.toISOString()).subscribe(
      data => {
        this.histFlights = data;
        this.dataSource = new MatTableDataSource<FlightDepartureData>();
        this.dataSource.data = this.histFlights.flightDepartureData;
        this.dataSource.paginator = this.paginator;
        this.loader = false;
        //console.log('hist flight details received from api: ' + JSON.stringify(this.histFlights));
      },
      res => {
        if (res) {
          if (res.status !== 200) {
            this.dataSource = null;
            this.loader = false;

          }
        }
      }
    )

  }

  onDepOrArrSelect(depOrArrival) {
    if (depOrArrival == '2') {
      this.dataSource = new MatTableDataSource<FlightArrivalData>();
      this.dataSource.data = this.histFlights.flightArrivalData;
      this.dataSource.paginator = this.paginator;
    }
    else {
      this.dataSource = new MatTableDataSource<FlightDepartureData>();
      this.dataSource.data = this.histFlights.flightDepartureData;
      this.dataSource.paginator = this.paginator;
    }
  }

  onSelectAirport(airport) {
    this.station = airport;
    this.depOrArr = '1';
    this.router.navigate(['history', this.station, { from: this.fromDate.toISOString(), to: this.toDate.toISOString() }]);
  }
  getFromDate(type: string, event: MatDatepickerInputEvent<Date>) {
    this.fromDate = event.value;
    //console.log('selected fromDate:  ' + this.fromDate);
    this.fromDate.setHours(this.fromHour);
    this.fromDate.setMinutes(this.fromMinute);
    //console.log('selected iso fromDate:  ' + this.fromDate.toISOString());
    this.router.navigate(['history', this.station, { from: this.fromDate.toISOString(), to: this.toDate.toISOString() }]);
  }
  getToDate(type: string, event: MatDatepickerInputEvent<Date>) {
    this.toDate = event.value;
    //console.log('selected fromDate:  ' + this.fromDate);
    this.toDate.setHours(this.toHour);
    this.toDate.setMinutes(this.toMinute);
    //console.log('selected iso fromDate:  ' + this.fromDate.toISOString());
    this.router.navigate(['history', this.station, { from: this.fromDate.toISOString(), to: this.toDate.toISOString() }]);
  }
  onFromHourSelect(frmHour): void {
    this.fromHour = frmHour;
    this.fromDate.setHours(this.fromHour);
    //console.log('onFromHourSelect iso fromDate:  ' + this.fromDate.toISOString());
    this.router.navigate(['history', this.station, { from: this.fromDate.toISOString(), to: this.toDate.toISOString() }]);
  }
  onFromMinuteSelect(frmMin): void {
    this.fromMinute = frmMin;
    this.fromDate.setMinutes(this.fromMinute);
    //console.log('onFromMinuteSelect iso fromDate:  ' + this.fromDate.toISOString());
    this.router.navigate(['history', this.station, { from: this.fromDate.toISOString(), to: this.toDate.toISOString() }]);
  }
  onToHourSelect(toHour): void {
    this.toHour = toHour;
    this.toDate.setHours(this.toHour);
    //console.log('onToHourSelect iso toDate:  ' + this.toDate.toISOString());
    this.router.navigate(['history', this.station, { from: this.fromDate.toISOString(), to: this.toDate.toISOString() }]);
  }
  onToMinuteSelect(toMin): void {
    this.toMinute = toMin;
    this.toDate.setMinutes(this.toMinute);
    //console.log('onToMinuteSelect iso toDate:  ' + this.toDate.toISOString());
    this.router.navigate(['history', this.station, { from: this.fromDate.toISOString(), to: this.toDate.toISOString() }]);
  }

  //#region file export functions  
  exportHistPdf() { this.exportAsService.save(this.exportAsConfigPdf, this.histFileName + new Date().toISOString().slice(0, 10)); }
  exportHistCsv() { this.exportAsService.save(this.exportAsConfigCsv, this.histFileName + new Date().toISOString().slice(0, 10)); }
  exportHistExcel() { this.exportAsService.save(this.exportAsConfigExcel, this.histFileName + new Date().toISOString().slice(0, 10)); }
  //#endregion


  highlight(row) {
    if (this.selectedRowKey == row.FLK)
      this.selectedRowKey = '';
    else
      this.selectedRowKey = row.FLK;
  }

}
