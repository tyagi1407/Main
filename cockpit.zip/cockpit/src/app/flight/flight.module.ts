import { CUSTOM_ELEMENTS_SCHEMA, NgModule, } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, DatePipe } from '@angular/common';
//user-defined imports
import { FlightRoutingModule } from './flight-routing.module';
import { MaterialModule } from './../material/material.module';
import { HomeComponent } from './components/home/home.component';
import { SharedModule } from '../shared/shared.module';
import { ArrivalComponent } from './components/arrival/arrival.component';
import { DepartureComponent } from './components/departure/departure.component';
import { BroadcastModule } from '../broadcast/broadcast.module';
import { FlightDetailDepartureComponent } from './components/flight-detail-departure/flight-detail-departure.component';
import { FlightMessageComponent } from './components/flight-message/flight-message.component';
import { FlightDetailArrivalComponent } from './components/flight-detail-arrival/flight-detail-arrival.component';
import { HistoryComponent } from './components/history/history.component';
import { ProfileRoutingModule } from '../profile/profile-routing.module';



@NgModule({
  declarations: [HomeComponent, ArrivalComponent, DepartureComponent, FlightDetailDepartureComponent, FlightMessageComponent, FlightDetailArrivalComponent, HistoryComponent],
  imports: [BroadcastModule,ProfileRoutingModule, CommonModule, FlightRoutingModule, FormsModule, ReactiveFormsModule, SharedModule, MaterialModule],
  exports: [HomeComponent,DepartureComponent,ArrivalComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [DatePipe]
})
export class FlightModule { }
