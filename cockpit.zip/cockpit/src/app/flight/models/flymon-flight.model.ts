
export interface DepartureAircrafts {  
    DID: number;
    RGA: any;
    ACM: any;
    CSG: string;
    ICT: string;
    LMF: any;
    PSC: string;
    REG: string;
    TYS: string;
    TYP: string;
    TOR: string;
    SDC: Date;
    SDM: Date;
}

export interface DepartureAirports {
    DID: number;
    APF: any;
    APN: any;
    CAA: any;
    CAM: string;
    CIR: string;
    DRM: any;
    GAT: any;
    GST: string;
    MID: any;
    MSD: any;
    DPE: any;
    PPF: any;
    PPN: any;
    DPS: any;
    RDL: any;
    RWY: string;
    SG2: any;
    SGT: string;
    TAR: string;
    TGP: string;
    TER: string;
    ZON: string;
    SDC: Date;
    SDM: Date;
}

export interface DepartureBaggages {
    DID: number;
    BID: any;
    BGT: number;
    BLL: number;
    BTL: number;
    BTR: number;
    SDC: Date;
    SDM: Date;
}
export interface DepartureDelays {
    DID: number;
    IR1: any;
    IR2: any;
    IR3: any;
    IR4: any;
    DL1: number;
    DL2: number;
    DL3: number;
    DL4: number;
    IX1: any;
    IX2: any;
    IX3: any;
    IX4: any;
    SDC: Date;
    SDM: Date;
}

export interface DepartureRoutes {
    DID: number;
    EAN: Date;
    PDS: string;
    PV1: any;
    PV2: any;
    VI1: any;
    VI2: any;
    SDC: Date;
    SDM: Date;
}

export interface DepartureHandlers {
    DID: number;
    HCG: string;
    HCA: string;
    HCI: string;
    HCL: string;
    HCB: string;
    HMM: string;
    HPX: string;
    HPU: string;
    HRA: string;
    HDL: string;
    HDI: string;
    SDC: Date;
    SDM: Date;
}

export interface DepartureLinkAndShare {   
    DID: number;
    LKD: any;
    LKF: any;
    LKR: any;
    LKS: any;
    SST: any;
    SDC: Date;
    SDM: Date;
}

export interface DepartureLoads {  
    DID: number;
    CGO: any;
    DDL: any;
    LDI: any;
    MLA: any;
    ULC: number;
    SDC: Date;
    SDM: Date;
}

export interface DeparturePassengers {
    DID: number;
    PBT: any;
    PXC: any;
    PXL: any;
    PAX: number;
    PCB: any;
    PXT: any;
    SDC: Date;
    SDM: Date;
}

export interface DepartureTimes {
    AEF: any;
    ATC: any;
    DID: number;
    ADC: any;
    AAN: any;
    ATD: Date;
    ADV: any;
    AD1: any;
    AD2: any;
    AD3: any;
    ABT: Date;
    AOT: Date;
    ABF: any;
    ASB: any;
    ASS: any;
    BTT: Date;
    CLE: Date;
    DOM: number;
    DAY: number;
    DOP: number;
    ETD: Date;
    ED1: any;
    ED2: any;
    ED3: Date;
    FCD: any;
    GAD: Date;
    LTD: Date;
    MGT: string;
    STN: Date;
    STD: Date;
    SED: Date;
    SUT: Date;
    LDX: string;
    TFM: any;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalAircrafts {
    DID: number;
    RGA: string;
    ACM: string;
    PSC: string;
    REG: string;
    TYS: string;
    TYP: string;
    TOR: string;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalAirports {
    DID: number;
    GAT: any;
    CAR: any;
    RWY: any;
    TAR: string;
    TGP: string;
    TER: string;
    ZON: string;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalBaggages {
    DID: number;
    BID: any;
    BGT: any;
    BLL: any;
    BTL: any;
    BTR: any;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalHandlers {
    DID: number;
    HCG: string;
    HCA: string;
    HCL: string;
    HCB: string;
    HLF: string;
    HMM: string;
    HPX: string;
    HPU: string;
    HRA: string;
    HDL: string;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalLinkAndShare {
    DID: number;
    LKD: any;
    LKF: any;
    LKR: any;
    LKS: any;
    MFF: any;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalLoads {   
    DID: number;
    CGO: any;
    DDL: any;
    LDI: any;
    MLA: any;
    ULC: any;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalPassengers {
    DID: number;
    PXC: any;
    PXL: any;
    PAX: any;
    PXT: any;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalRoutes {
    DID: number;
    ADP: any;
    EDP: Date;
    SDP: any;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalTimes {
    DID: number;
    ATA: any;
    DOM: number;
    DOP: number;
    DAY: number;
    ETA: any;
    FCD: any;
    STA: Date;
    STP: Date;
    TTM: any;
    SDC: Date;
    SDM: Date;
}

export interface ArrivalDelays {
    DID: number;
    IR1: any;
    IR2: any;
    IR3: any;
    IR4: any;
    DL1: number;
    DL2: number;
    DL3: number;
    DL4: number;
    IX1: any;
    IX2: any;
    IX3: any;
    IX4: any;
    SDC: Date;
    SDM: Date;
}



export interface FlymonFlight {
    FLK: string;
    DMI: any;
    FCC: string;
    FLN: number;
    FLX: any;
    GVF: string;
    FTY: string;
    ITY: any;
    MIS: any;
    NAT: string;
    REM: any;
    TRA: any;
    SDC: Date;
    SDM: Date;
    FLCName: string;
    ORG: string;
    DESName: string;
    FLC: string;
    DES: string;
    FLCID: number;
    ORGID: number;
    ORGName: string;
    DESID: number;
    departureAircrafts: DepartureAircrafts;
    departureAirports: DepartureAirports;
    departureBaggages: DepartureBaggages;
    departureDelays: DepartureDelays;
    departureHandlers: DepartureHandlers;
    departureLinkAndShare: DepartureLinkAndShare;
    departureLoads: DepartureLoads;
    departurePassengers: DeparturePassengers;
    departureRoutes: DepartureRoutes;
    departureTimes: DepartureTimes;
    arrivalAircrafts: ArrivalAircrafts;
    arrivalAirports: ArrivalAirports;
    arrivalBaggages: ArrivalBaggages;
    arrivalDelays: ArrivalDelays;
    arrivalHandlers: ArrivalHandlers;
    arrivalLinkAndShare: ArrivalLinkAndShare;
    arrivalLoads: ArrivalLoads;
    arrivalPassengers: ArrivalPassengers;
    arrivalRoutes: ArrivalRoutes;
    arrivalTimes: ArrivalTimes;

    /*arrival extra parameters*/
    PLT: string;
    RM1: any;
    RM3: any;
    CSG: string;
    MIA: string;
    MSA: string;
    SST: string;
    BUS: string;

}

