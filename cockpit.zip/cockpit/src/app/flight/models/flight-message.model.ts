export class FlightMessage {
   
    FLC: string;
    FLN: string;
    FLX: string;
    FLR: string;
    
}