export class Flight {
    //common    
    FLK: string;
    FLN: string;
    FLC: string;
    ORG: string;
    DES: string;
    TAR: string;
    IR1: string;
    TYP: string;
    SCH: string;
    REM: string;
    LKF: string;
    SDT: string;
    //departure
    STD: string;
    ETD: string;
    ATD: string;
    ATC: string;
    ADV: string;
    PBT: string;
    GAT: string;
    GST: string;

    TOR: string;
    MIS: string;
    ABF: string;
    ABT: string;
    AD1: string;
    AD2: string;
    AD3: string;
    ADC: string;
    AEF: string;
    AOT: string;
    ASB: string;
    ASS: string;
    BTT: string;
    CIR: string;
    CLE: string;
    PAX: string;
    PSC: string;
    MGT: string;
    MID: string;
    LMF: string;
    PCB: string;
    SED: string;
    //arrival
    ATA: string;
    STA: string;
    ETA: string;
    DEL: string; 
    LTD: string; 
    LTA: string;
    VI1: string;
    VI2: string;
    TER: string;
    TDT: string;
    STP: string;
    MSA: string;
    MIA: string;
    LKR: string;
    FCD: string;
    FCC: string;
    EDP: string;
    
    //new 
    FLT: string;
    UPD: string;


}