import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewBroadcastComponent } from './components/view-broadcast/view-broadcast.component';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [ ViewBroadcastComponent],
  imports: [CommonModule,ReactiveFormsModule],
  exports: [ViewBroadcastComponent],
})
export class BroadcastModule { }
