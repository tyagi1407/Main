export class Message {
    id?: string;//delete, send broadcast id when user removes message from broadcast  
    messageId?: string;
    message?: string;//view,create 
    sender?: string;//create  
    hashTags?: string[];
    //role: string;//create
    //station: string;//create   
    createTime?: Date;//view,create
    //receit: string;//view
}