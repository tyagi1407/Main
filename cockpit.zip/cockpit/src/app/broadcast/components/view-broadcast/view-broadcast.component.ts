import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { BroadcastService } from './../../../core/services/broadcast.service';
import { Message } from '../../models/message.model';
import { AnimationBuilder } from '@angular/animations';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { interval } from 'rxjs';

@Component({
  selector: 'flymon-view-broadcast',
  templateUrl: './view-broadcast.component.html',
  styleUrls: ['./view-broadcast.component.css']
})
export class ViewBroadcastComponent implements OnInit, OnChanges {

  messageArray: Message[];// = [{ id: '', messageId: '', hashTags: [''], message: '', sender: '', createTime: new Date() }];
  message: Message;
  user: string;
  @Input() station: string;
  today = new Date().toISOString();

  messageForm = new FormGroup({
    station: new FormControl(''),
    message: new FormControl(''),
  });
  //carpos: number = 0;
  //isMessageDeleted: boolean = true;
  //currentSlide: number = 0;
  //timing: string = '250ms ease-in';
  //@ViewChild('carousal') private carousal: ElementRef;
  //private player: AnimationPlayer;

  constructor(private route: ActivatedRoute, private broadcastService: BroadcastService) {
  }

  ngOnInit() {
    var t = interval(30000);    //get data on specific interval
    t.subscribe(val => this.getMessages()
    );
  }

  ngOnChanges(): void {
    this.user = sessionStorage.getItem('user');
    this.getMessages();
  }

  getMessages() {
    let msg: Message = { sender: this.user, hashTags: ['#' + this.station] };
    this.broadcastService.getUnreadByHashTags(msg).subscribe(
      data => { this.messageArray = data; },
      // res => {
      //   if (res) {
      //     if (res.status !== 200) {  //TODO: what to do?
      //       this.messageArray = [];
      //       console.log(res.message);
      //     }
      //   }
      // },
      err => {
        //this.messageArray = null;
        //console.error('error received in ViewBroadcastComponent-getMessages(): ' + err);
      }
    )
  }

  onSendMessage() {
    //console.log(this.messageForm.value);
    const hashDefaultStation = '#' + this.station;
    var tagsArray: string[];

    if (this.messageForm.controls['station'].value != null) {
      tagsArray = this.messageForm.controls['station'].value.split(' ').filter(v => v.startsWith('#'));
      if (tagsArray.indexOf(hashDefaultStation) < 0)
        tagsArray.push(hashDefaultStation);   //add current selected station 
    }
    else {
      const tagsArray2: string[] = [hashDefaultStation];
      tagsArray = tagsArray2;
    }

    let msg: Message = { message: this.messageForm.controls['message'].value, sender: this.user, hashTags: tagsArray };
    this.broadcastService.sendMessage(msg).subscribe(
      data => { this.getMessages(); },
      err => console.error('error received in ViewBroadcastComponent-onSendMessage(): ' + err)
    );
    this.messageForm.reset();
  }

  onMessageRead(id: string) {
    //console.log(id);
    let msg: Message = { sender: this.user, messageId: id };
    this.broadcastService.markReadMessage(msg).subscribe(
      data => { this.getMessages(); },
      err => console.error('error received in ViewBroadcastComponent-onMessageRead(): ' + err)
    );
  }


  //#region commented code
  //onNextClick() {
  //this.carpos++;
  // let len = 1;
  // if (this.messageArray)
  //   len = this.messageArray.length;
  // if (this.currentSlide + 1 === len) return;
  // this.currentSlide = (this.currentSlide + 1) % len;
  // const offset = this.currentSlide * 950;
  // const myAnimation: AnimationFactory = this.builder.build([
  //   animate(this.timing, style({ transform: `translateX(-${offset}px)` }))
  // ]);
  // const player = myAnimation.create(this.carousal.nativeElement)
  // player.play();
  //}
  //onPrevClick() {
  // let len = 1;
  // if (this.messageArray)
  //   len = this.messageArray.length;
  // if (this.currentSlide === 0) return;
  // this.currentSlide = ((this.currentSlide - 1) + len) % len;
  // const offset = this.currentSlide * 950;
  // const myAnimation: AnimationFactory = this.builder.build([
  //   animate(this.timing, style({ transform: `translateX(-${offset}px)` }))
  // ]);
  // const player = myAnimation.create(this.carousal.nativeElement)
  // player.play();
  //}

  //#endregion

}
