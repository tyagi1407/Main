import { Injectable } from '@angular/core';
//angular imports
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';




//user-defined files
import { environment } from 'src/environments/environment';
import { ProfileView } from 'src/app/profile/models/profile.model';
import { element } from '@angular/core/src/render3';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {


  //variables
  profiles: string[];
  admins: string[];
  private profileServiceURL = environment.apiProfileURL;


  constructor(private http: HttpClient) {
  }


  //get functions  

  getProfile(user: string, type: string): Observable<ProfileView> {
    let urlParams = 'getViewDetail' + '/' + type + '/' + user;
    let getProfileUrl = this.profileServiceURL + urlParams;
    return this.http.get<ProfileView>(getProfileUrl);

  }

  getPropertyNamesFromJson(json: string): string[] {
    let array: string[] = [];
    var object = JSON.parse(json);
    Object.getOwnPropertyNames(object).filter(function (value) {
      if (object[value].length > 0)
        array.push(value);
    });
    return array;
  }

  getProfileByName(category: string, name: string): Observable<ProfileView> {
    let urlParams = 'getViewDetail' + '/' + category + '/' + name;
    let getProfileUrl = this.profileServiceURL + urlParams;
    return this.http.get<ProfileView>(getProfileUrl);

  }

  getProfileNames(category: string): Observable<string[]> {
    let urlParams = 'profilesNames/' + category;
    let getProfileNamesUrl = this.profileServiceURL + urlParams;
    return this.http.get<string[]>(getProfileNamesUrl);

  }

  //get admin
  getAdmins(): Observable<string[]> {
    let urlParams = 'profilesNames/admin';
    let getProfileNamesUrl = this.profileServiceURL + urlParams;
    return this.http.get<string[]>(getProfileNamesUrl);

  }

  // async getAdmins2() {
  //   let urlParams = 'profilesNames/admin';
  //   let getProfileNamesUrl = this.profileServiceURL + urlParams;
  //   const result = this.http.get<string[]>(getProfileNamesUrl).toPromise();

  //   return result;
  // }


  //check public profile exists before creating
  CheckPublicProfile(newProfile: string): boolean {
    newProfile = newProfile.trim();
    if (this.profiles) {
      if (this.profiles.findIndex(item => newProfile.toLowerCase() === item.toLowerCase()) < 0) {
        return false;
        //TODO:refresh page
      }
      else return true;
    }
    else {
      let url = this.profileServiceURL + 'profilesNames/public';
      //console.log('1');
      this.http.get<string[]>(url).subscribe(
        data => {
          this.profiles = data;
          // console.log(this.profiles);
          //console.log('2');
        },
        err => { return false; }
      );

    }

  }

  private async getProfiles(url: string): Promise<string[]> {
    return await this.http.get<string[]>(url).toPromise();
  }

  //post functions

  saveProfile(user: string, profile: ProfileView): any {
    //http://10.75.2.122:8083/ProfileApid/profile/create/ak00000   

    //if profile does not exists then create otherwise update it, same api route is used for create and update
    let url = this.profileServiceURL + 'create/' + user;
    profile.name = profile.name.trim();
    let profileBody = JSON.stringify(profile);
    //console.log(profileBody);
    return this.http.post(url, profileBody, this.getProfileHeaders());
  }


  updateProfile(user: string, profile: ProfileView): any {
    //http://10.75.2.122:8083/ProfileApid/profile/update/ak00000
    let url = this.profileServiceURL + 'update/' + user;
    let profileBody = JSON.stringify(profile);
    //console.log(profileBody);
    return this.http.post(url, profileBody, this.getProfileHeaders());
  }

  getFilterJson(json: string, array: string[]): string {
    let sortedObject = JSON.parse('{}');
    if (json.length == 0) {
      array.forEach(element => {
        sortedObject[element] = '';
      });
    }
    else {
      let object = JSON.parse(json);
      array.forEach(element => {
        if (object[element] == '') sortedObject[element] = '';
        else sortedObject[element] = object[element];
      });
    }
    console.log(JSON.stringify(sortedObject));
    return JSON.stringify(sortedObject);

  }


  //private functions

  private getProfileHeaders(): any {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };
    return httpOptions;
  }



}
