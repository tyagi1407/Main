import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { ProfileService } from './profile.service';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable()

export class AuthGuardService implements CanActivate {
    admins: string[];

    constructor(public profileService: ProfileService, public router: Router) {
    }

    canActivate(): Observable<boolean> {
        const user = sessionStorage.getItem('user');
        //return true;            
        return this.profileService.getAdmins().pipe(map(
            data => {
                this.admins = data;
                //console.log(this.admins);
                //console.log(user);
                if (this.admins.indexOf(user.toLowerCase()) == -1) {
                    this.router.navigate(['error']);
                    return false;
                }
                else return true;

            })
        )
    }

}