import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PrintService {

  constructor() { }

  public print(htmlSectionId: string, header: string) {
    const printContents = document.getElementById(htmlSectionId).innerHTML;
    const stylesHtml = this.getTagsHtml('style');
    const linksHtml = this.getTagsHtml('link');
    const popupWin = window.open('', '_blank', 'top=150,left=150,height=800,width=1000');
    popupWin.document.open();
    popupWin.document.write(`
    <html>
        <head>
            <title>${header}</title>
            ${linksHtml}
            ${stylesHtml}           
        </head>
        <body onload="window.print(); window.close()">
            ${printContents}
        </body>
    </html>
    `
    );
    popupWin.document.close();
  }

  private getTagsHtml(tagName: keyof HTMLElementTagNameMap): string {
    const htmlStr: string[] = [];
    const elements = document.getElementsByTagName(tagName);
    for (let idx = 0; idx < elements.length; idx++) {
      htmlStr.push(elements[idx].outerHTML);
    }
    return htmlStr.join('\r\n');
  }
}
