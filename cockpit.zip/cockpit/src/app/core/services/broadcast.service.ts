import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { environment } from './../../../environments/environment';
import { Message } from '../../broadcast/models/message.model';




@Injectable({
    providedIn: 'root'
})
export class BroadcastService {

    apiBroadcastURL: string = environment.apiBroadcastURL;

    constructor(private http: HttpClient) {
    }

    //get functions

    //post functions
    getUnreadByHashTags(message: Message): any {
        // http://10.75.2.122:8080/Messaged/messages/unreadByHashTags/gt305655
        // body- {"hashTags": ["#ZRH","#Cleaning"]} 

        let messageData = JSON.stringify(message.hashTags, (key, value) => {
            if (value !== null) return value
        });
        //console.log(messageData);
        let urlParams = 'unreadByHashTag/' + message.sender;
        let url = this.apiBroadcastURL + urlParams;

        return this.http.post<Message[]>(url, messageData, this.getOptions());
    }


    sendMessage(message: Message): any {
        // http://10.75.2.122:8080/Messaged/messages/create
        // body- {"sender":"gt305655","message":"Flight delays at #ZRH #Cleaning ","hashTags":["#Cleaning","#GVA"]}

        let messageData = JSON.stringify(message, (key, value) => {
            if (value !== null) return value
        });
        //console.log(messageData);
        let urlParams = 'create';
        let url = this.apiBroadcastURL + urlParams;
        return this.http.post<Message>(url, messageData, this.getOptions());
    }

    markReadMessage(message: Message): any {
        // http://10.75.2.122:8080/Messaged/messages/markRead/gt12345
        // body- {"messageId":"54"} 

        let messageData = JSON.stringify(message, (key, value) => {
            if (value !== null) return value
        });
        //console.log(messageData);
        let urlParams = 'markRead/' + message.sender;
        let url = this.apiBroadcastURL + urlParams;
        return this.http.post<boolean>(url, message, this.getOptions());
    }


    //private functions
    private getOptions(): any {
        const options = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        }
        return options;
    }





}