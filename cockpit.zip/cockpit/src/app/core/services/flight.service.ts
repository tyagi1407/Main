import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from './../../../environments/environment';
import { FlymonFlight } from 'src/app/flight/models/flymon-flight.model';
import { HistoryFlight } from 'src/app/flight/models/flight-history';



@Injectable({
  providedIn: 'root'
})
export class FlightService {

  apiFlightURL: string = environment.apiFlightURL;

  constructor(private http: HttpClient) {
  }

  getFlightsFromStation(station: string, depOrArr: string, from: string, to: string): Observable<FlymonFlight[]> {
    //console.log('flight service getFlightsFromStation received params-  station=' + station + '  depOrArr=' + depOrArr + '  from=' + from + '  to=' + to);
    //http://10.75.2.122:8080/FlymonApid/getFlights/ZRH/departure?fromDate=2018-08-06%2000:00:00&toDate=2019-08-08%2000:00:00

    //for testing
    //from = "2018-10-02T11:44:00.00Z";
    //to = "2019-11-02T11:44:00.00Z";

    var currentTime = new Date();
    //console.log(currentTime.toISOString());
    let defaultFromDate = new Date(Date.now() - 1 * 60 * 60 * 1000);
    let defaultToDate = new Date(Date.now() + 3 * 60 * 60 * 1000);

    let params = station + '/' + depOrArr;
    if (from == undefined && to == undefined) {
      params = params + '?' + 'fromDate=' + defaultFromDate.toISOString() + '&' + 'toDate=' + defaultToDate.toISOString();
    }
    else if (from !== undefined) {
      params = params + '?' + 'fromDate=' + from;
      if (to !== undefined)
        params = params + '&' + 'toDate=' + to;
    }
    else if (to !== undefined) {
      params = params + '?' + 'toDate=' + to;
    }

    let flightUrl = this.apiFlightURL + params;
    //console.log('flightUrl: ' + flightUrl);
    return this.http.get<FlymonFlight[]>(flightUrl);
  }

  getFlightDetails(flightKey: string, station: string, depOrArr: string): Observable<FlymonFlight> {
    //console.log('flight service getFlightDetails received params-  key=' + flightKey + ' station=' + station + '  depOrArr=' + depOrArr);
    //http://10.75.2.122:8080/FlymonApid/getFlights/BSL/departure/AZA57220190716
    let params = station + '/' + depOrArr + '/' + flightKey;
    let flightDetailUrl = this.apiFlightURL + params;
    //console.log('flightDetailUrl: ' + flightDetailUrl);
    return this.http.get<FlymonFlight>(flightDetailUrl);
  }

  getHistoricalFlightDetails(station: string, from: string, to: string): Observable<HistoryFlight> {
    //console.log('flight service getFlightsFromStation received params-  station=' + station + '  depOrArr=' + depOrArr + '  from=' + from + '  to=' + to);
    //http://10.75.2.122:8080/FlymonApid/getFlights/ZRH/departure?fromDate=2018-08-06%2000:00:00&toDate=2019-08-08%2000:00:00

    let params = station;
    if (from !== undefined) {
      params = params + '?' + 'fromDate=' + from;
      if (to !== undefined)
        params = params + '&' + 'toDate=' + to;
    }
    else if (to !== undefined) {
      params = params + '?' + 'toDate=' + to;
    }
    let flightUrl = this.apiFlightURL + params;
    //console.log('flightUrl: ' + flightUrl);
    return this.http.get<HistoryFlight>(flightUrl);
  }

  getPropertyNamesFromJson(json: string): string[] {
    let array: string[] = [];
    var object = JSON.parse(json);
    array = Object.getOwnPropertyNames(object);
    // Object.getOwnPropertyNames(object).filter(function (value) {
    //   if (object[value].length > 0)
    //     array.push(value);
    // });
    return array;
  }

}
