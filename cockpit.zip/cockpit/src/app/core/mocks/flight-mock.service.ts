import { Injectable } from '@angular/core';
import { Flight } from './../../flight/models/flight.model';

@Injectable({
  providedIn: 'root'
})
export class FlightMockService {

  flightData: Flight[] = [
    // { FLC: 'LX', FLN: '2140', FLR: '0', FLX: 's', SDT: '20190614', ORG: 'ZRH', NAT: 'S', TAR: 'D', GAT: 'F', REG: 'A', RGA: 'B', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'AI', FLN: '1234', FLR: '0', FLX: 'd', SDT: '20180615', ORG: 'BSL', NAT: 'T', TAR: 'G', GAT: 'A', REG: 'W', RGA: 'D', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LU', FLN: '9852', FLR: '0', FLX: 'w', SDT: '20170616', ORG: 'GVA', NAT: 'I', TAR: 'K', GAT: 'B', REG: 'R', RGA: 'L', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LH', FLN: '2140', FLR: '0', FLX: 'o', SDT: '20160617', ORG: 'ZRH', NAT: 'P', TAR: 'L', GAT: 'C', REG: 'L', RGA: 'C', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'TK', FLN: '6541', FLR: '0', FLX: 'p', SDT: '20150618', ORG: 'BSL', NAT: 'E', TAR: 'Q', GAT: 'D', REG: 'J', RGA: 'L', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'UI', FLN: '6543', FLR: '0', FLX: 'y', SDT: '20140619', ORG: 'GVA', NAT: 'Q', TAR: 'M', GAT: 'I', REG: 'H', RGA: 'W', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LX', FLN: '2140', FLR: '0', FLX: 'm', SDT: '20190612', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'AI', FLN: '1256', FLR: '0', FLX: 'm', SDT: '20180613', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LH', FLN: '3256', FLR: '0', FLX: 'm', SDT: '20170614', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LX', FLN: '2140', FLR: '0', FLX: 'm', SDT: '20160615', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'TK', FLN: '1466', FLR: '0', FLX: 'm', SDT: '20190616', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LX', FLN: '2560', FLR: '0', FLX: 'm', SDT: '20180617', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LX', FLN: '2140', FLR: '0', FLX: 'm', SDT: '20190612', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'AI', FLN: '1256', FLR: '0', FLX: 'm', SDT: '20180613', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LH', FLN: '3256', FLR: '0', FLX: 'm', SDT: '20170614', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LX', FLN: '2140', FLR: '0', FLX: 'm', SDT: '20160615', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'TK', FLN: '1466', FLR: '0', FLX: 'm', SDT: '20190616', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' },
    // { FLC: 'LX', FLN: '2560', FLR: '0', FLX: 'm', SDT: '20180617', ORG: 'ZRH', NAT: 'F', TAR: 'Z', GAT: 'L', REG: 'W', RGA: 'Q', CSG: 'D', EOB: 'DF', EOBD: 'ED', FLS: 'ER', FLSB: 'QWE', GST: 'SXC', GSTC: 'NBG', TYS: 'WSD', TYSA: 'EDF' }
  
  ]

  constructor() { }

  getFlights(): Flight[] {
    return this.flightData;
  }
}
