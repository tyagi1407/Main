import { Injectable } from '@angular/core';
import { Message } from '../../broadcast/models/message.model';

@Injectable({
    providedIn: 'root'
})
export class BroadcastMockService {

    messageData: Message[];
    // = [
    //{ sender: 'AFIS', role: 'Admin',  message: 'flight delayed by 30 mins' },
    //{ sender: 'AFIS', role: 'Admin', message: 'Flight delayed due to heavy snow' }

    // ]

    constructor() { }

    getMessage(): Message[] {
        return this.messageData;
    }
}
