import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
//user-defined imports
import { BroadcastModule } from './broadcast/broadcast.module';
import { MaterialModule } from './material/material.module';
import { FlightModule } from './flight/flight.module';
import { SharedModule } from './shared/shared.module';
import { MsAdalAngular6Module } from 'microsoft-adal-angular6';
import { ExportAsModule } from 'ngx-export-as';
import { ProfileModule } from './profile/profile.module';
import { AuthGuardService } from './core/services/auth-guard.service';


@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, BroadcastModule, BrowserAnimationsModule, ExportAsModule, FlightModule, ProfileModule, HttpClientModule, MaterialModule,
    MsAdalAngular6Module.forRoot(getAdalConfig), SharedModule, RouterModule.forRoot([])],
  exports: [],
  providers: [AuthGuardService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})

export class AppModule {

}


//adal configurations
export function getAdalConfig() {
  return {
    instance: 'https://sso.swissport.com/',
    tenant: 'adfs',
    clientId: '06c84d13-5482-4697-932e-8b07c276c68d',
    redirectUri: window.location.origin + '/cockpit/',
    postLogoutRedirectUri: window.location.origin + '/',
    endpoints: {
      //'https://ops-auth.swissport.aero/oauthapi': 'https://ops-auth.swissport.aero/oauthapi', // as registered in ADFS
      //'https://ops-dev2.swissport.aero/': 'https://ops-dev2.swissport.aero/', // as registered in ADFS 
      'https://detcsaspms0352.corp.ads.swissport.aero:8343/': 'https://detcsaspms0352.corp.ads.swissport.aero:8343/'
    }
    //  navigateToLoginRequestUrl: false,
    //cacheLocation: '<localStorage / sessionStorage>',
  };
}




