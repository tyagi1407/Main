export interface ProfileView {
    createdBy: string;
    name: string;
    viewType: number;
    role: number;
    viewDel: ViewDetail[];

}
export interface ViewDetail {
    category: string;
    //viewOrder: string[];
    viewOrder: string;
}
