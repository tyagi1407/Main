import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfileHomeComponent } from './components/profile-home/profile-home.component';
import { AuthGuardService as AuthGuard } from '../core/services/auth-guard.service';
import { ProfileErrorComponent } from './components/profile-error/profile-error.component';


const profileRoutes: Routes = [
  { path: 'create-profile/:station', component: ProfileHomeComponent, canActivate: [AuthGuard] },
  { path: 'create-profile', redirectTo: '/create-profile/zrh', pathMatch: 'full', canActivate: [AuthGuard] },
  { path: 'profile/:station', component: ProfileHomeComponent },
  { path: 'error', component: ProfileErrorComponent }
];


@NgModule({
  declarations: [],
  imports: [RouterModule.forChild(profileRoutes)],
  exports: [RouterModule]

})



export class ProfileRoutingModule { }
