import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileHomeComponent } from './components/profile-home/profile-home.component';
import { ProfileRoutingModule } from './profile-routing.module';
import { CoreModule } from '../core/core.module';
import { SharedModule } from '../shared/shared.module';
import { MaterialModule } from '../material/material.module';
import { FlightModule } from '../flight/flight.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProfileErrorComponent } from './components/profile-error/profile-error.component';

@NgModule({

  declarations: [ProfileHomeComponent, ProfileErrorComponent],
  imports: [CommonModule, ProfileRoutingModule, CoreModule, FormsModule, ReactiveFormsModule, FlightModule, SharedModule, MaterialModule],
  exports: [ProfileHomeComponent]

})
export class ProfileModule { }
