import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'flymon-profile-error',
  templateUrl: './profile-error.component.html',
  styleUrls: ['./profile-error.component.css']
})
export class ProfileErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
