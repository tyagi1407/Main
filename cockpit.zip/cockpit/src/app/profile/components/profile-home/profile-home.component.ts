import { Component, OnInit, ViewChild } from '@angular/core';
import { ProfileService } from 'src/app/core/services/profile.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ProfileView, ViewDetail } from '../../models/profile.model';
import { FormGroup, FormControl } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material';
import { HeaderComponent } from 'src/app/shared/components/header/header.component'
import { DepartureComponent } from 'src/app/flight/components/departure/departure.component';
import { ArrivalComponent } from 'src/app/flight/components/arrival/arrival.component';

@Component({
  selector: 'flymon-profile-home',
  templateUrl: './profile-home.component.html',
  styleUrls: ['./profile-home.component.css']
})
export class ProfileHomeComponent implements OnInit {

  hidePanel: string = '1';
  showHidePanel: boolean = false;
  station: string = "ZRH";    //default
  panel: string = "none";
  fromHour: string = '00';
  fromMinute: string = '00';
  toHour: string = '00';
  toMinute: string = '00';
  today = new Date().toISOString();
  //material variables 
  day = 3;
  hour = 3;
  minDate = new Date(Date.now() - this.day * 24 * 60 * 60 * 1000);
  maxDate = new Date(Date.now() + this.day * 24 * 60 * 60 * 1000);
  fromDate: Date;//= new Date(Date.now() - this.day * 24 * 60 * 60 * 1000);
  toDate: Date;// = new Date(Date.now() + this.day * 24 * 60 * 60 * 1000);
  //to set the default value on direct route
  routeFromDate = new FormControl(new Date(Date.now() - this.hour * 60 * 60 * 1000));
  routeToDate = new FormControl(new Date(Date.now() + this.hour * 60 * 60 * 1000));
  @ViewChild(HeaderComponent, { read: false }) headerComp: HeaderComponent;
  @ViewChild(DepartureComponent) departureComp: DepartureComponent;
  @ViewChild(ArrivalComponent) arrivalComp: ArrivalComponent;

  public activeMobileTab: any = "departure";
  checkLabel: string;
  depFilterJson: string;
  arrFilterJson: string;
  isAdminPage: boolean = false;
  stn: string;
  profileView: ProfileView;
  depColumns: string[] = [];
  arrColumns: string[] = [];
  profName: string;
  isCreate: boolean = false;
  profileForm = new FormGroup({
    profile: new FormControl('')
  });


  constructor(private profileService: ProfileService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {

    if (this.router.url.toLowerCase().toString().indexOf('create-profile') == -1)
      this.isAdminPage = true;

    //set url params   
    this.route.params.subscribe(params => {
      if (params['station']) {
        this.stn = params['station'];
        this.station = this.stn.toUpperCase();
      }
    });
    //set query params 
    this.route.queryParams.subscribe(queryParams => {
      if (queryParams.from) {
        this.fromDate = new Date(queryParams.from);
        this.routeFromDate.setValue(this.fromDate);
        this.fromHour = this.addZero(this.fromDate.getHours().toString());
        this.fromMinute = this.addZero(this.fromDate.getMinutes().toString());
      }
      if (queryParams.to) {
        this.toDate = new Date(queryParams.to);
        this.routeToDate.setValue(this.toDate);
        this.toHour = this.addZero(this.toDate.getHours().toString());
        this.toMinute = this.addZero(this.toDate.getMinutes().toString());
      }
      if (queryParams.name) {
        this.profName = queryParams.name;
        this.getPublicProfileViewByName('public');
      }
      else {
        this.profName = 'private';
        this.getProfileView(this.profName);
      }
    });
  }

  //functions    
  onHideClick(id: string) {
    let depElement = document.getElementById("departure_wrap");
    let arrElement = document.getElementById("arrival_wrap");
    if (id === '2') {//hide departure       
      depElement.classList.remove('col-md-6');
      arrElement.classList.remove('nodisp', 'col-md-6');
      depElement.classList.add('nodisp', 'col-md-12');
      arrElement.classList.add('col-md-12');
    }
    else if (id === '3') {//hide arrival         
      arrElement.classList.remove('col-md-6');
      depElement.classList.remove('nodisp', 'col-md-6');
      arrElement.classList.add('nodisp', 'col-md-12');
      depElement.classList.add('col-md-12');
    }
    else if (id === '1') {//hide none      
      depElement.classList.remove('nodisp', 'col-md-12');
      arrElement.classList.remove('nodisp', 'col-md-12');
      depElement.classList.add('col-md-6');
      arrElement.classList.add('col-md-6');
    }
  }
  getFromDate(type: string, event: MatDatepickerInputEvent<Date>) {
    this.fromDate = event.value;  //console.log('selected fromDate:  ' + this.fromDate);
    this.fromDate.setHours(this.removeZero(this.fromHour));
    this.fromDate.setMinutes(this.removeZero(this.fromMinute));    //console.log('selected iso fromDate:  ' + this.fromDate.toISOString());
    this.router.navigate(['profile', this.station], { queryParams: { name: this.profName, from: this.fromDate == undefined ? undefined : this.fromDate.toISOString(), to: this.toDate == undefined ? undefined : this.toDate.toISOString() } });
  }
  getToDate(type: string, event: MatDatepickerInputEvent<Date>) {
    this.toDate = event.value;    //console.log('selected fromDate:  ' + this.fromDate);
    this.toDate.setHours(this.removeZero(this.toHour));
    this.toDate.setMinutes(this.removeZero(this.toMinute));    //console.log('selected iso fromDate:  ' + this.fromDate.toISOString());
    this.router.navigate(['profile', this.station], { queryParams: { name: this.profName, from: this.fromDate == undefined ? undefined : this.fromDate.toISOString(), to: this.toDate == undefined ? undefined : this.toDate.toISOString() } });
  }
  onHideDropdownClick(): void {
    this.showHidePanel = !this.showHidePanel;
  }
  onPrfSelectAirport(airport) {
    this.station = airport;
    this.router.navigate(['profile', this.station], { queryParams: { name: this.profName, from: this.fromDate == undefined ? undefined : this.fromDate.toISOString(), to: this.toDate == undefined ? undefined : this.toDate.toISOString() } });
  }
  onFromHourSelect(frmHour): void {
    this.fromHour = frmHour;
    this.fromDate.setHours(this.removeZero(this.fromHour));    //console.log('onFromHourSelect iso fromDate:  ' + this.fromDate.toISOString());
    this.router.navigate(['profile', this.station], { queryParams: { name: this.profName, from: this.fromDate == undefined ? undefined : this.fromDate.toISOString(), to: this.toDate == undefined ? undefined : this.toDate.toISOString() } });
  }
  onFromMinuteSelect(frmMin): void {
    this.fromMinute = frmMin;
    this.fromDate.setMinutes(this.removeZero(this.fromMinute));    //console.log('onFromMinuteSelect iso fromDate:  ' + this.fromDate.toISOString());
    this.router.navigate(['profile', this.station], { queryParams: { name: this.profName, from: this.fromDate == undefined ? undefined : this.fromDate.toISOString(), to: this.toDate == undefined ? undefined : this.toDate.toISOString() } });
  }
  onToHourSelect(toHour): void {
    this.toHour = toHour;
    this.toDate.setHours(this.removeZero(this.toHour)); //console.log('onToHourSelect iso toDate:  ' + this.toDate.toISOString());
    this.router.navigate(['profile', this.station], { queryParams: { name: this.profName, from: this.fromDate == undefined ? undefined : this.fromDate.toISOString(), to: this.toDate == undefined ? undefined : this.toDate.toISOString() } });
  }
  onToMinuteSelect(toMin): void {
    this.toMinute = toMin;
    this.toDate.setMinutes(this.removeZero(this.toMinute));     //console.log('onToMinuteSelect iso toDate:  ' + this.toDate.toISOString());
    this.router.navigate(['profile', this.station], { queryParams: { name: this.profName, from: this.fromDate == undefined ? undefined : this.fromDate.toISOString(), to: this.toDate == undefined ? undefined : this.toDate.toISOString() } });
  }
  removeZero(time: string): number {
    if (time[0] === '0') return + time[1];
    else return +time;
  }
  addZero(time: string): string {
    if (time.length == 1) return time = "0" + time;
    else return time;
  }
  onDepartureMobileTabClick(activeTabParam) {
    this.activeMobileTab = activeTabParam;
    let depElement = document.getElementById('prf-departure_tab');
    let arrElement = document.getElementById('prf-arrival_tab');
    arrElement.classList.remove('active');
    depElement.classList.add('active');
  }
  onArrivalMobileTabClick(activeTabParam) {
    this.activeMobileTab = activeTabParam;
    let depElement = document.getElementById('prf-departure_tab');
    let arrElement = document.getElementById('prf-arrival_tab');
    depElement.classList.remove('active');
    arrElement.classList.add('active');
  }

  //get profile details
  getProfileView(category: string) {
    this.profileService.getProfile(sessionStorage.getItem('user'), category).subscribe(
      data => {
        this.profileView = data;
        //api should return profiles, having departure and arrival both
        this.depFilterJson = this.profileView.viewDel.filter(x => x.category == 'D')[0].viewOrder;
        this.arrFilterJson = this.profileView.viewDel.filter(x => x.category == 'A')[0].viewOrder;
        this.depColumns = this.profileService.getPropertyNamesFromJson(this.depFilterJson);
        this.arrColumns = this.profileService.getPropertyNamesFromJson(this.arrFilterJson);
        // console.log(this.depColumns);
        // console.log(this.arrColumns);
      },
      error => {
        //send empty in case user has not created any private profile or in case of error        
        this.depFilterJson = '';
        this.arrFilterJson = '';
      }
    )
  }

  //get public profile details from route name
  getPublicProfileViewByName(category: string) {
    this.profileService.getProfileByName(category, this.profName).subscribe(
      data => {
        this.profileView = data;
        //api should return profiles, having departure and arrival both
        this.depFilterJson = this.profileView.viewDel.filter(x => x.category == 'D')[0].viewOrder;
        this.arrFilterJson = this.profileView.viewDel.filter(x => x.category == 'A')[0].viewOrder;
        this.depColumns = this.profileService.getPropertyNamesFromJson(this.depFilterJson);
        this.arrColumns = this.profileService.getPropertyNamesFromJson(this.arrFilterJson);
        //console.log(this.depColumns);
        //console.log(this.arrColumns);
      }
    )
  }

  //create new public profile
  onCreateProfile() {

    if (this.profileForm.controls['profile'].value != null) {
      const depFilters = this.profileService.getFilterJson('', this.departureComp.displayedColumns);
      const arrFilters = this.profileService.getFilterJson('', this.arrivalComp.displayedArrColumns);

      let view: ViewDetail[] = [{ category: 'D', viewOrder: depFilters }, { category: 'A', viewOrder: arrFilters }]
      // role-1(admin),  viewType- 0(public),1(private)
      let profile: ProfileView = { name: this.profileForm.controls['profile'].value, role: 1, viewType: 0, createdBy: sessionStorage.getItem('user'), viewDel: view };

      this.profileService.saveProfile(sessionStorage.getItem('user'), profile).subscribe(
        data => {
          this.headerComp.getPublicProfiles();
        },
        err => { }
      );
      this.profileForm.reset();
    }
  }

  onUpdateProfile() {

    if (this.profileForm.controls['profile'].value != null) {
      const depFilters = this.profileService.getFilterJson(this.departureComp.depFilterJson, this.departureComp.displayedColumns);
      const arrFilters = this.profileService.getFilterJson(this.arrivalComp.arrFilterJson, this.arrivalComp.displayedArrColumns);
      let view: ViewDetail[] = [{ category: 'D', viewOrder: depFilters }, { category: 'A', viewOrder: arrFilters }];
      //let view: ViewDetail[] = [{ category: 'D', viewOrder: this.depColumns }, { category: 'A', viewOrder: this.arrColumns }];
      // role-1(admin),  viewType- 0(public),1(private)
      let profile: ProfileView = { name: this.profileForm.controls['profile'].value, role: 1, viewType: 0, createdBy: sessionStorage.getItem('user'), viewDel: view };

      this.profileService.updateProfile(sessionStorage.getItem('user'), profile).subscribe(
        data => {
          //console.log('3');
        },
        err => { }
      );
      this.profileForm.reset();
    }



  }

  onCheckPublicProfile() {
    if (this.profileForm.controls['profile'].value != null) {
      this.isCreate = this.profileService.CheckPublicProfile(this.profileForm.controls['profile'].value);
      if (!this.isCreate)
        this.checkLabel = "Not exists";
      else
        this.checkLabel = "Already exists";
      //this.router.navigate(['profile', this.station], { queryParams: { name: this.profName, from: this.fromDate == undefined ? undefined : this.fromDate.toISOString(), to: this.toDate == undefined ? undefined : this.toDate.toISOString() } });

    }


  }



}
