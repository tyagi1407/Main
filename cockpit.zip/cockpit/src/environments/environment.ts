export const environment = {
  production: false,

  //set this to enable mock service
  mock: false,

  //dev urls  
  apiTokenURL: 'https://ops-auth.swissport.aero/oauthapi/',
  // apiFlightURL: 'http://10.75.2.122:8080/FlymonApid/getFlights/',
  // apiBroadcastURL: 'http://10.75.2.122:8081/Messaged/messages/',
  // apiProfileURL: 'http://10.75.2.122:8083/ProfileApid/profile/',


  // apiFlightURL: 'https://flymonapi-qa.corp.ads.swissport.aero/flymonapi/getFlights/',
  // apiBroadcastURL: 'http://message-qa.corp.ads.swissport.aero/message/messages/',
  // apiProfileURL: 'http://profileapi-qa.corp.ads.swissport.aero/profileapi/profile/',

  
  apiFlightURL: 'https://detcsaspms0352.corp.ads.swissport.aero/flymonapi/getFlights/',
  apiBroadcastURL: 'https://detcsaspms0352.corp.ads.swissport.aero:8443/message/messages/',
  apiProfileURL: 'https://detcsaspms0352.corp.ads.swissport.aero:8143/profileapi/profile/',



  //qa urls  
  // apiTokenURL: 'https://cockpitapiq.corp.ads.swissport.aero:8443/oauthapi/',
  // apiFlightURL: 'https://cockpitapiq.corp.ads.swissport.aero:8443/FlymonApiq/getFlights/',
  // apiBroadcastURL: 'https://cockpitapiq.corp.ads.swissport.aero:9443/Messageq/messages/'


  //prod urls  
  // apiTokenURL: 'https://cockpitapip.corp.ads.swissport.aero:8443/oauthapi/',   
  // apiFlightURL: 'https://cockpitapip.corp.ads.swissport.aero:8443/FlymonApip/getFlights/',
  // apiBroadcastURL: 'https://cockpitapip.corp.ads.swissport.aero:8443/Messagep/messages/'


};


