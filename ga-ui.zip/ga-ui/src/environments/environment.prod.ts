export const environment = {
  production: true,

  apiIntegrationURL: 'http://gateapp.corp.ads.swissport.aero/integration'
};
