import { Component, OnInit, Input } from '@angular/core';
import { IntegrationService } from 'src/app/core/services/integration.service';
import { ActivatedRoute } from '@angular/router';
import { GateStatus } from '../../models/gate-status.model';
import { interval } from 'rxjs';
import { Location } from '@angular/common';


@Component({
  selector: 'gateapp-gate-detail',
  templateUrl: './gate-detail.component.html',
  styleUrls: ['./gate-detail.component.css']
})
export class GateDetailComponent implements OnInit {

  flightKey: string;
  gateStatus: GateStatus;
  countDownDate: number;
  etd: Date;
  interval;
  timeStatus: string;

  constructor(private service: IntegrationService, private route: ActivatedRoute, private location: Location) { }

  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      if (params.flightKey) {
        this.flightKey = params.flightKey;
        this.getGateDetails();
        this.CountDownTimer();
      }
    });
    var t = interval(5000);
    t.subscribe(val => { this.getGateDetails(); }   //get data on specific interval
    );
  }

  private getGateDetails() {
    this.service.getGateDetails(this.flightKey).subscribe((data) => {
      this.gateStatus = data;
      this.etd = this.gateStatus.estimatedTimeofDeparture == null ? this.gateStatus.scheduleTimeOfDeparture : this.gateStatus.estimatedTimeofDeparture;
      if (this.timeStatus == "Delayed") {
        this.CountDownTimer();
      }
      //console.log(this.etd);
      //console.log(this.gateStatus);
    }, (error) => { });
  }

  onbackClick() {
    this.location.back();
  }

  CountDownTimer() {
    clearInterval(this.interval);
    //Update the count down every 1 second
    this.interval = setInterval(() => {
      //Set the ETD date  
      this.countDownDate = new Date(this.etd).getTime()    //new Date("Jan 31, 2020 15:12:00").getTime();
      var now = new Date().getTime();
      var interval = this.countDownDate - now;
      var hours = Math.floor((interval % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = Math.floor((interval % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = Math.floor((interval % (1000 * 60)) / 1000);
      var time = hours * 60 + minutes;
      if (document.getElementById("gd-count")) {
        this.timeStatus = this.service.pad(time, 2) + ":" + this.service.pad(seconds, 2);
        document.getElementById("gd-count").innerHTML = this.timeStatus;
      }
      if (interval < 0) {
        clearInterval(this.interval);   //once clear interval is done then angular route need to be changed in case of update in time in database        
        this.timeStatus = "Delayed";
        document.getElementById("gd-count").innerHTML = this.timeStatus;
      }
    }, 1000);
  }




}
