import { Component, OnInit } from '@angular/core';
import { Flight } from 'src/app/task/models/flight.model';


@Component({
  selector: 'gateapp-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  userId: string = 'gt989898';  //TODO: get from session object
  flights: Flight[];

  ngOnInit() { }

  onFlightEvent(flights: Flight[]) {
    this.flights = flights;
    //console.log(this.flight);
  }

}
