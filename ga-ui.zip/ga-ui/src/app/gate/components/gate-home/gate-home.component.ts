import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'gateapp-gate-home',
  templateUrl: './gate-home.component.html',
  styleUrls: ['./gate-home.component.css']
})
export class GateHomeComponent implements OnInit {

  flightKey: string;
  showDelay: boolean = false;  

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      if (params.flightKey) {
        //console.log(params.flightKey);
        this.flightKey = params.flightKey;
      }
    });
  }

  toggleDelaySpeech() {
    this.showDelay = !this.showDelay;
  }

}

