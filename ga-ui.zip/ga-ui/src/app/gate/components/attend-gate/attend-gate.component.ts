import { Component, OnInit } from '@angular/core';
import { IntegrationService } from 'src/app/core/services/integration.service';
import { Status } from 'src/app/task/models/status.model';
import { ActivatedRoute } from '@angular/router';
import { interval } from 'rxjs';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'gateapp-attend-gate',
  templateUrl: './attend-gate.component.html',
  styleUrls: ['./attend-gate.component.css']
})
export class AttendGateComponent implements OnInit {

  status: Status;
  processName: string = 'AttendGate';
  toggle: boolean = true;
  flightKey: string;
  countDownDate: number;
  etd: Date;
  interval;
  timeStatus: string = '';
  error: string;
  disable: boolean;

  constructor(private service: IntegrationService, private route: ActivatedRoute, private datePipe: DatePipe) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params.flightKey && params.sts) {
        //console.log(params.flightKey);
        //console.log(params.sts);
        this.flightKey = params.flightKey;
        this.disable = params.sts == 'UPCOMING' ? true : false;
        this.error = null;
        this.getStatus();
      }
    });

    var t = interval(5000);
    t.subscribe(val => { this.getStatus(); }   //get data on specific interval
    );

  }

  getStatus() {
    //console.log('1');
    this.service.getStatus(this.flightKey).subscribe(
      (data) => {
        //console.log(data);
        if (data.length > 0) {
          this.status = data.find(x => x.name == this.processName);
          this.etd = new Date(new Date(this.status.estimatedTimeofDeparture).getTime() - 45 * 60000);
          //console.log(this.status);        
          if (!this.status) {
            this.status = { status: 0 };  //if status does not exists in database then default status is NOTSTARTED
          }
          if (this.status && this.status.status == 2) {
            //console.log(this.status);
            clearInterval(this.interval);
            this.timeStatus = "Completed: " + this.datePipe.transform(this.status.updateTime, 'HH:mm').toString();
            //console.log(this.timeStatus);            
          }
          else {
            //console.log(this.status);
            this.CountDownTimer();
          }
        }
        else {
          this.status = { status: 1 };  //if status does not exists in database then default status is INPROGRESS
        }
      },
      (error) => {
        this.status = { status: 0 };  //if status does not exists in database then default status is NOTSTARTED
      }
    );
  }


  updateStatus() {
    if (this.validateAttendGateTime()) {
      //raise an event to change the status 'attended' of boarding gate in AIMS
      //if event is raised successfully, then api will update the status to completed in database
      this.service.updateBoardingGateStatus(this.flightKey, 'A').subscribe(
        (data) => {
          this.getStatus(); //get latest status 
          var element = <HTMLInputElement>document.getElementById("chck1");
          element.checked = !element.checked;
          this.toggle = !this.toggle;
        },
        (error) => { }
      );
    }
    else {
      //display error message
      this.error = "Attend Gate can not be completed 60 mins before departure."

    }
  }

  validateAttendGateTime(): boolean {

    //validation to allow attend gate only before 60 mins
    var departureTime = this.status.estimatedTimeofDeparture == null ? this.status.scheduleTimeofDeparture : this.status.estimatedTimeofDeparture;
    //console.log(departureTime);
    var interval = new Date(departureTime).getTime() - new Date().getTime();
    var hours = Math.floor((interval % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = hours * 60 + Math.floor((interval % (1000 * 60 * 60)) / (1000 * 60));
    //console.log(minutes);
    if (minutes <= 60) {
      return true;
    }
    else {
      return false;
    }

  }

  onTabClick() {
    this.toggle = !this.toggle;
  }

  CountDownTimer() {
    clearInterval(this.interval);
    //Update the count down every 1 second
    this.interval = setInterval(() => {
      //Set the ETD date  
      this.countDownDate = new Date(this.etd).getTime()    //new Date("Jan 31, 2020 15:12:00").getTime();
      var now = new Date().getTime();
      var interval = this.countDownDate - now;
      var hours = Math.floor((interval % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = Math.floor((interval % (1000 * 60 * 60)) / (1000 * 60));
      //var seconds = Math.floor((interval % (1000 * 60)) / 1000);
      var time = hours * 60 + minutes;
      this.timeStatus = "Time Left: " + this.service.pad(time, 2) + "'";
      if (interval < 0) {
        clearInterval(this.interval);   //once clear interval is done then angular route need to be changed in case of update in time in database        
        this.timeStatus = "Delayed";
      }
    }, 1000);

  }



}
