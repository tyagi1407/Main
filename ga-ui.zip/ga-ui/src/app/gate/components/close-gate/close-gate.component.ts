import { Component, OnInit } from '@angular/core';
import { IntegrationService } from 'src/app/core/services/integration.service';
import { ActivatedRoute } from '@angular/router';
import { Status } from 'src/app/task/models/status.model';
import { interval } from 'rxjs';
import { DatePipe } from '@angular/common';
import { MissingPassenger } from '../../models/missing-passenger.model';
import { BoardingDelay } from '../../models/boarding-delay.model';


@Component({
  selector: 'gateapp-close-gate',
  templateUrl: './close-gate.component.html',
  styleUrls: ['./close-gate.component.css']
})
export class CloseGateComponent implements OnInit {
  missingPassengers: MissingPassenger[] = [];
  toggle: boolean = true;
  flightKey: string;
  status: Status;
  processName: string = 'CloseGate';
  countDownDate: number;
  etd: Date;
  interval;
  timeStatus: string = '';
  error: string;
  info: string;
  selectedMin: string;
  selectedReason: string;
  reasons: string[] = ['Crew', 'Coordinator', 'Cleaning', 'Other'];
  delayMins: string[] = ['Select', '1', '2', '3', '5'];
  disable: boolean;
  totalBags: number = 0;
  delayToETD: boolean = false;
  delayStart: Date = null;
  oldBoardingTime: Date = null;
  isIntervalZero: boolean = false;

  constructor(private service: IntegrationService, private route: ActivatedRoute, private datePipe: DatePipe) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params.flightKey && params.sts) {
        this.flightKey = params.flightKey;
        this.disable = params.sts == 'UPCOMING' ? true : false;
        this.error = null;
        this.info = null;
        this.getStatus();
        this.getMissingPassenger();
      }
    });
    var t = interval(3000);
    t.subscribe(val => {
      this.getStatus();    //get data on specific interval
      this.getMissingPassenger();
    }
    );

  }
  getMissingPassenger() {
    this.service.getMissingPassenger(this.flightKey).subscribe(
      (data) => {
        this.missingPassengers = data;
        var bagCount = 0;
        this.missingPassengers.forEach(x => bagCount = bagCount + x.bags.length);
        this.totalBags = bagCount;
      }
    );
  }
  updateStatus() {
    if (this.validateCloseGateTime()) {
      //1. raise an event to change the status of boarding gate in AIMS
      //2. if event is raised successfully, then api will update the status to completed in database
      //3. raise an event to notify hcc if bags are 3 or less
      //4. notify flight coordinator
      this.service.updateBoardingGateStatus(this.flightKey, 'C').subscribe(
        (data) => {
          var element = <HTMLInputElement>document.getElementById("chck8");
          element.checked = !element.checked;
          this.toggle = !this.toggle;
          this.getStatus(); //get latest status
          this.service.notifyHCCForBagSearch(this.flightKey).subscribe(
            (data) => { },
            (error) => { }
          )
        },
        (error) => { }
      );
    }
    else {
      this.error = "The gate can be closed from 12 minutes before departure.";
      return false;
    }
  }
  validateCloseGateTime(): boolean {

    //validation to allow attend gate only before 60 mins
    var departureTime = this.status.estimatedTimeofDeparture == null ? this.status.scheduleTimeofDeparture : this.status.estimatedTimeofDeparture;
    //console.log(departureTime);
    var interval = new Date(departureTime).getTime() - new Date().getTime();
    var hours = Math.floor((interval % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = hours * 60 + Math.floor((interval % (1000 * 60 * 60)) / (1000 * 60));
    //console.log(minutes);
    if (minutes <= 12) {
      return true;
    }
    else {
      return false;
    }

  }
  getStatus() {
    this.service.getStatus(this.flightKey).subscribe(
      (data) => {
        if (data.length > 1) {
          this.status = data.find(x => x.name == this.processName);
          //console.log(this.status);
          this.SetCounterTime();
          //check/set the status
          if (!this.status) {
            this.status = { status: 0 };  //if status does not exists in database then default status is NOTSTARTED
          }
          if (this.status && this.status.status == 2) {
            clearInterval(this.interval);
            this.timeStatus = "Completed: " + this.datePipe.transform(this.status.updateTime, 'HH:mm').toString();
          }
          else {
            this.CountDownTimer();
            //TODO: this counter is running when delayed 
          }
        }
        else {
          clearInterval(this.interval);
          this.timeStatus = '';
          this.status = { status: 0 };  //if status does not exists in database then default status is NOTSTARTED
        }
      },
      (error) => {
        clearInterval(this.interval);
        this.timeStatus = '';
        this.status = { status: 0 };
      }
    );
  }
  SetCounterTime() {
    var departureTime = this.status.estimatedTimeofDeparture == null ? this.status.scheduleTimeofDeparture : this.status.estimatedTimeofDeparture;

    if (this.oldBoardingTime != null && this.oldBoardingTime != departureTime) {
      //this means etd has been updated, then ignore all the delays 
      this.updateDelay(-1, false, false);//IMP:delay value is sent -1 so that wait to etd becomes zero in db 
      //console.log('etd update triggered');
    }
    else if (this.status.boardingDelay == null) {
      this.etd = new Date(new Date(departureTime).getTime() - this.status.timeBeforeETD * 60000);
      //console.log('delay not reached till now');
    }
    else {
      let delayStart = JSON.parse(this.status.boardingDelay)["CloseGateDetail"]["DelayStart"];
      let waitToETD = JSON.parse(this.status.boardingDelay)["CloseGateDetail"]["WaitToETD"];
      let delay = JSON.parse(this.status.boardingDelay)["CloseGateDetail"]["CloseGate"];
      if (delayStart == null) {
        //console.log('delay not reached');
        //delay has not reached and counter is still running, just update the etd
        if (delay > 0 && waitToETD == 0)
          this.etd = new Date(new Date(departureTime).getTime() + delay * 60000 - this.status.timeBeforeETD * 60000);
        else if (delay == 0 && waitToETD == 1)
          this.etd = departureTime;
        else 
        this.etd = new Date(new Date(departureTime).getTime() + delay * 60000 - this.status.timeBeforeETD * 60000);
      }
      else {
        //console.log('delay reached');
        //delay was reached atleast once
        if (delay == 0 && waitToETD == 0) {
          var interval = new Date(departureTime).getTime() - new Date(delayStart).getTime();
          var minutes = Math.floor((interval % (1000 * 60 * 60)) / (1000 * 60));
          //console.log(minutes);
          if (minutes > 7) {
            this.CountDownTimer();
            this.etd = departureTime;
          }         
          else {
            //clearInterval(this.interval);
            //this.etd = departureTime;
            //console.log('nan..');
            this.timeStatus = "Delayed";
          }

        }
        else if (delay > 0 && waitToETD == 0) {
          //console.log('delay reach and delay gt 0');
          this.etd = new Date(new Date(delayStart).getTime() + delay * 60000);
          if (this.timeStatus == 'Delayed') {this.CountDownTimer();console.log('show delayed and counter started..');}
        }
        else if (delay == 0 && waitToETD == 1)
          this.etd = departureTime;
      }

    }
    //set to compare if etd has been updated in next call  
    this.oldBoardingTime = departureTime;

  }


  updateDelay(delay: number, delayStart: boolean = false, isUpdate: boolean = false) {
    let boardingDelay: BoardingDelay = {
      CloseGateDetail: {
        CloseGate: delay < 0 ? 0 : delay,
        DelayStart: delayStart ? new Date().toISOString() : null,
        WaitToETD: delay == 0 ? '1' : '0',
        IsUpdateDelayStart: isUpdate ? '1' : '0'
      }
    };
    this.service.updateDelay(this.flightKey, boardingDelay).subscribe(
      (data) => {
        if (delay != 0 && delay != -1) this.info = delay + " mins of delay added.";
        //else this.info = "delay added upto std/etd.";
        //console.log(data);
      },
      (error) => { }
    );
  }

  onTabClick() {
    this.toggle = !this.toggle;
  }

  CountDownTimer() {
    clearInterval(this.interval);
    //Update the count down every 1 second
    this.interval = setInterval(() => {
      //Set the ETD date  
      this.countDownDate = new Date(this.etd).getTime()
      var now = new Date().getTime();
      var interval = this.countDownDate - now;
      var hours = Math.floor((interval % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = Math.floor((interval % (1000 * 60 * 60)) / (1000 * 60));
      //var seconds = Math.floor((interval % (1000 * 60)) / 1000);
      var time = hours * 60 + minutes;
      this.timeStatus = "Time Left: " + this.service.pad(time, 2) + "'";
      //console.log(interval);
      if(isNaN(interval)) this.timeStatus = "Delayed";
      if (interval < 0) {
        //update the delay to zero in db
        this.updateDelay(-1, true, true);        
        clearInterval(this.interval);
        this.timeStatus = "Delayed";
      }
    }, 1000);

  }




}
