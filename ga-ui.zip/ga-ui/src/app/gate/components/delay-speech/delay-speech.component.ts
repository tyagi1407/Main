import { Component, OnInit } from '@angular/core';
import { Status } from 'src/app/task/models/status.model';
import { IntegrationService } from 'src/app/core/services/integration.service';
import { ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { interval } from 'rxjs';
import { BoardingDelay } from '../../models/boarding-delay.model';

@Component({
  selector: 'gateapp-delay-speech',
  templateUrl: './delay-speech.component.html',
  styleUrls: ['./delay-speech.component.css']
})
export class DelayComponent implements OnInit {
  delaySpeech: string;
  flightKey: string;
  status: Status;
  processName: string = 'DelaySpeech';
  toggle: boolean = true;
  countDownDate: number;
  etd: Date;
  interval;
  timeStatus: string = '';
  destination: string;
  disable: boolean;
  checkedReasons: string[] = [];
  reasons: string[] = ['Crew', 'Coordinator', 'Cleaning', 'Other'];
  delayReasons = [
    { value: 'Crew', checked: false },
    { value: 'Coordinator', checked: false },
    { value: 'Cleaning', checked: false },
    { value: 'Other', checked: false },
  ];
  delayMins: string[] = ['Select', '1', '2', '3', '5'];
  selectedMin: string;
  selectedReason: string;
  error: string;
  info: string;
  show: boolean = false;


  constructor(private service: IntegrationService, private route: ActivatedRoute, private datePipe: DatePipe) { }

  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      if (params.flightKey && params.dest && params.sts) {
        this.flightKey = params.flightKey;
        this.destination = params.dest;
        this.disable = params.sts == 'UPCOMING' ? true : false;
        //console.log(this.flightKey + this.destination);        
        this.error = null;
        this.info = null;
        this.getStatus();
        this.getDelaySpeech();
      }
    });
    var t = interval(5000);
    t.subscribe(val => { this.getStatus(); }   //get data on specific interval
    );
  }

  getStatus() {
    this.service.getStatus(this.flightKey).subscribe(
      (data) => {
        if (data.length > 1) {
          this.status = data.find(x => x.name == this.processName);
          var departureTime = this.status.estimatedTimeofDeparture == null ? this.status.scheduleTimeofDeparture : this.status.estimatedTimeofDeparture;
          this.etd = new Date(new Date(departureTime).getTime() - this.status.timeBeforeETD * 60000);
          //console.log(this.status);
          //console.log(this.etd);
          // var temp = new Date(departureTime).getTime()    
          // var now = new Date().getTime();
          // var interval = temp - now;
          // var hours = Math.floor((interval % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          // var minutes = Math.floor((interval % (1000 * 60 * 60)) / (1000 * 60));
          // //var seconds = Math.floor((interval % (1000 * 60)) / 1000);
          // var time = hours * 60 + minutes;
          // if (time < 26)
          //   this.show = true;

          if (!this.status) {
            this.status = { status: 0 };  //if status does not exists in database then default status is NOTSTARTED
          }
          if (this.status && this.status.status == 2) {
            clearInterval(this.interval);
            this.timeStatus = "Completed: " + this.datePipe.transform(this.status.updateTime, 'HH:mm').toString();
          }
          else {
            this.CountDownTimer();
          }
        }
        else {
          clearInterval(this.interval);
          this.timeStatus = '';
          this.status = { status: 0 };  //if status does not exists in database then default status is NOTSTARTED
        }
      },
      (error) => {
        clearInterval(this.interval);
        this.timeStatus = '';
        this.status = { status: 0 };
      }
    );
  }

  updateStatus() {
    let newStatus: Status = { flightKey: this.flightKey, name: this.processName, status: 2 };
    this.service.updateStatus(newStatus).subscribe(
      (data) => {
        this.getStatus();
        var element = <HTMLInputElement>document.getElementById("chck9");
        element.checked = !element.checked;
        this.toggle = !this.toggle;
      }
    );
  }

  updateDelayReasonCheckBox(value) {
    for (var i = 0; i < this.delayReasons.length; i++) {
      if (this.delayReasons[i].value == value) {
        this.delayReasons[i].checked = !this.delayReasons[i].checked;
        this.checkedReasons.splice(this.checkedReasons.indexOf(value), 1);
      }
    }
  }

  notifyHCCCheckbox() {
    let checked = this.delayReasons.filter(x => x.checked == true);
    if (checked.length > 0 && this.selectedMin != undefined && this.selectedMin != 'Select') {
      for (var i = 0; i < checked.length; i++) {
        if (this.checkedReasons.indexOf(checked[i].value) < 0)
          this.checkedReasons.push(checked[i].value);
      }
      //console.log(this.checkedReasons);
      //console.log(this.selectedMin);
    }
    else {
      alert('please select reason and delay time');
    }

  }

  updateDelay(minute: number) {
    let boardingDelay: BoardingDelay = {
      BoardingSpeech: minute,
      BoardingStart: minute,
      CloseGateDetail: { CloseGate: 0, DelayStart: null, WaitToETD: '0', IsUpdateDelayStart: '0' }
    };
    this.service.updateDelay(this.flightKey, boardingDelay).subscribe(
      (data) => {
        //console.log(data);
      },
      (error) => { }
    );
  }

  notifyHCC() {
    this.info = null;
    this.error = null;
    if (this.selectedMin != undefined && this.selectedReason != undefined && this.selectedMin != 'Select') {
      this.error = null;
      this.service.notifyHCC(this.flightKey, this.selectedMin, this.selectedReason).subscribe(
        (data) => {
          //console.log(data);
          if (data.indexOf('event created') !== -1) {
            this.info = "HCC notified.";
            this.updateDelay(+this.selectedMin);
          }
          else this.error = "Could not notify HCC currently."

        },
        (error) => {
          this.error = "Could not notify HCC currently."
        }
      );
    }
    else {
      this.error = "Select reason and delay both.";
    }
  }

  onReasonSelect(reason) {
    this.selectedReason = reason;
    //console.log(reason);
  }

  onDelaySelect(min) {
    this.selectedMin = min;
    //console.log(min);
  }

  onTabClick() {
    this.toggle = !this.toggle;
  }

  getDelaySpeech() {
    this.service.getSpeech(this.flightKey, this.destination, "delay")
      .subscribe(data => {
        //console.log(data);
        if (data != null)
          this.delaySpeech = data.speeches["eng-GB"];   // en-GB is default language configured for Zurich station
        else this.delaySpeech = null;

      });
  }

  CountDownTimer() {
    clearInterval(this.interval);
    //Update the count down every 1 second
    this.interval = setInterval(() => {
      //Set the ETD date 
      //console.log(this.etd); 
      this.countDownDate = new Date(this.etd).getTime()    //new Date("Jan 31, 2020 15:12:00").getTime();
      var now = new Date().getTime();
      var interval = this.countDownDate - now;
      //console.log(interval);
      var hours = Math.floor((interval % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = Math.floor((interval % (1000 * 60 * 60)) / (1000 * 60));
      //var seconds = Math.floor((interval % (1000 * 60)) / 1000);
      var time = hours * 60 + minutes;
      this.timeStatus = "Time Left: " + this.service.pad(time, 2) + "'";
      if (interval < 0) {
        clearInterval(this.interval);   //once clear interval is done then angular route need to be changed in case of update in time in database        
        this.timeStatus = "Delayed";
      }
    }, 1000);

  }

}
