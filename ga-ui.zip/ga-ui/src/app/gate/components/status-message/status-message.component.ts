import { Component, OnInit } from '@angular/core';
import { IntegrationService } from 'src/app/core/services/integration.service';
import { ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Status } from 'src/app/task/models/status.model';
import { interval } from 'rxjs';
import { MissingPassenger } from '../../models/missing-passenger.model';

@Component({
  selector: 'gateapp-status-message',
  templateUrl: './status-message.component.html',
  styleUrls: ['./status-message.component.css']
})
export class StatusMessageComponent implements OnInit {
  missingPassengers: MissingPassenger[] = [];
  flightKey: string;
  status: Status;
  processName: string = 'StatusMessage';
  toggle: boolean = true;
  countDownDate: number;
  etd: Date;
  interval;
  timeStatus: string = '';
  disable: boolean;
  info: string;
  totalBags: number;
  error: string = null;
  success: string = null;

  constructor(private service: IntegrationService, private route: ActivatedRoute, private datePipe: DatePipe) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params.flightKey && params.sts) {
        this.flightKey = params.flightKey;
        this.disable = params.sts == 'UPCOMING' ? true : false;
        this.getStatus();
        this.getMissingPassenger();
        this.info=null; this.error=null; this.success = null;
      }
    });

    //this.getMissingPassenger();
    var t = interval(5000);
    t.subscribe(val => {
      this.getStatus();   //get data on specific interval
      this.getMissingPassenger();
    }
    );
  }

  getMissingPassenger() {
    this.service.getMissingPassenger(this.flightKey).subscribe(
      (data) => {        
        this.missingPassengers = data;
        var bagCount = 0;
        this.missingPassengers.forEach(x => bagCount = bagCount + x.bags.length);
        this.totalBags = bagCount;
        //console.log(this.missingPassengers);  
        if (this.missingPassengers.length < 1)
          this.info = 'There are no missing passengers at the moment.';
        else
          this.info = null;
      }
    );
  }

  getStatus() {
    this.service.getStatus(this.flightKey).subscribe(
      (data) => {
        //console.log(this.status); 
        if (data.length > 1) {
          this.status = data.find(x => x.name == this.processName);
          var departureTime = this.status.estimatedTimeofDeparture == null ? this.status.scheduleTimeofDeparture : this.status.estimatedTimeofDeparture;
          this.etd = new Date(new Date(departureTime).getTime() - this.status.timeBeforeETD * 60000);
          //console.log(this.status);
          //console.log(this.etd); 
          if (!this.status) {
            this.status = { status: 0 };  //if status does not exists in database then default status is NOTSTARTED
          }
          if (this.status && this.status.status == 2) {
            clearInterval(this.interval);
            this.timeStatus = "Completed: " + this.datePipe.transform(this.status.updateTime, 'HH:mm').toString();
          }
          else {
            this.CountDownTimer();
          }
        }
        else {
          clearInterval(this.interval);
          this.timeStatus = '';
          this.status = { status: 0 };  //if status does not exists in database then default status is NOTSTARTED
        }
      },
      (error) => {
        clearInterval(this.interval);
        this.timeStatus = '';
        this.status = { status: 0 };
      }
    );
  }

  updateStatus() {
    let newStatus: Status = { flightKey: this.flightKey, name: this.processName, status: 2 };
    //console.log(newStatus);
    this.service.updateStatus(newStatus).subscribe(
      (data) => {
        this.getStatus();
        var element = <HTMLInputElement>document.getElementById("chck10");
        element.checked = !element.checked;
        this.toggle = !this.toggle;
        this.success=null;
      }
    );
  }

  sendStatusMessage(){
    this.success="notification sent.";
  }

  onTabClick() {
    this.toggle = !this.toggle;
  }

  CountDownTimer() {
    clearInterval(this.interval);

    //Update the count down every 1 second
    this.interval = setInterval(() => {
      //Set the ETD date  
      this.countDownDate = new Date(this.etd).getTime()    //new Date("Jan 31, 2020 15:12:00").getTime();
      var now = new Date().getTime();
      var interval = this.countDownDate - now;
      var hours = Math.floor((interval % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = Math.floor((interval % (1000 * 60 * 60)) / (1000 * 60));
      //var seconds = Math.floor((interval % (1000 * 60)) / 1000);
      var time = hours * 60 + minutes;
      this.timeStatus = "Time Left: " + this.service.pad(time, 2) + "'";
      if (interval < 0) {
        clearInterval(this.interval);   //once clear interval is done then angular route need to be changed in case of update in time in database        
        this.timeStatus = "Delayed";
      }
    }, 1000);

  }

}
