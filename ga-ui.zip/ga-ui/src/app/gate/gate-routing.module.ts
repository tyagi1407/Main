import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { GateHomeComponent } from './components/gate-home/gate-home.component';
import { HomeComponent } from './components/home/home.component';

const gateRoutes: Routes = [
    { path: 'flights/:id', component: HomeComponent },    
    { path: 'flights/:id/:key', component: HomeComponent },    
    { path: 'gate', component: GateHomeComponent }, 
    { path: '', redirectTo: '/flights/gt305655', pathMatch: 'full' },
    { path: '**', component: AppComponent }  //TODO:implement error page
];

@NgModule({
    imports: [RouterModule.forChild(gateRoutes)],
    exports: [RouterModule]
})
export class GateRoutingModule { }


// /gateapp/task/gt305655
// /gateapp/task/gt305655/lx45620191225