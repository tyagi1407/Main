import { Flight } from './board-passenger.model';

export interface RootObject {
    products: Product[];
    status: Status[];
    reasonCode: ReasonCode;
    reasonText: ReasonText;
    customerId: string;
    firstName: string;
    lastName: string;
    type: string;
}

// export interface Flight {
//     marketingCarrier: string;
//     flightNumber: string;
//     departureDate: Date;
//     origin: string;
//     destination: string;
// }

export interface Product {
    productId: string;
    flight: Flight;
}

export interface Status {
    indicator: string;
    action: string;
}

export interface ReasonCode {
    function: string;
    type: string;
}

export interface ReasonText {
    qualifier: string;
    source: string;
    encoding: string;
    text: string;
}



