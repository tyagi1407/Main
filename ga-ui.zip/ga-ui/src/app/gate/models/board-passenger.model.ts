export interface BoardPassenger {
    productId: string;
    flight: Flight;
    customerId: string;
    firstName: string;
    lastName: string;
    type: string;
}

export interface Flight {
    marketingCarrier: string;
    flightNumber: string;
    departureDate: Date;
    origin: string;
    destination: string;
}