
export interface BoardingDelay {
    AttendGate?: number;
    COBSpeech?: number;
    PRMBoarding?: number;
    DelaySpeech?: number;
    BoardingSpeech?: number;
    BoardingStart?: number;
    PrintCrewList?: number;
    MissingPassenger?: number;
    StatusMessage?: number;
    CloseGateDetail?: CloseGateDetail;
}

export interface CloseGateDetail {
    CloseGate?: number;
    DelayStart?: string;
    WaitToETD?: string;
    IsUpdateDelayStart?: string;

}
