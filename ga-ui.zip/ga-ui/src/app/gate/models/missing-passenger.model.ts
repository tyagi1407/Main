export interface MissingPassenger {
    customerId: string;
    productId: string;
    title: string;
    firstName: string;
    lastName: string;
    seat: string;
    sequenceNumber: string;
    bookingClass: string;
    boardingStatus: string;
    gender: string;
    type: string;
    prmCategory: string;
    flightKey?: any;
    inboundFlightKey?: any;
    bagCount: number;
    bags: Bag[];
}

export interface Bag {
    // loadingSequence: string;
    // uld: string;
    // position: string;
    type: string;
    origin: string;
    destination: string;
    uldDeviceNumber:string;
    bagStatus: string;
    cabinClass: string;
    company: string;
    identifier: string;
    number: string;
    location: string;
    companyNumber: string;
    measurement: string;
    unitQualifier: string;
}


