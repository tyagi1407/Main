export class Speech {
    title: string;
    airline: string;
    remark: string;
    speeches: Record<string, string>;
}
