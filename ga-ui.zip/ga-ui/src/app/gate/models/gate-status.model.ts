export interface GateStatus {
    createTime: string;
    destination: string;
    endTimeOfDeparture: Date;
    estimatedTimeofDeparture: Date;
    flightCarrier: string;
    flightKey: string;
    flightNo: number;
    gate: string;
    gateStatus: string;
    origin: string;
    scheduleTimeOfDeparture: Date;
    tarmac: string;
    terminal: string;
    updateTime: string;
    type: string;
    registration: string
}

