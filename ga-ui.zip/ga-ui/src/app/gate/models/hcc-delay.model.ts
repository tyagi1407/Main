export interface HCCDelay {
    delayReason: string;
    expectedBoardingDelay: string;    
}