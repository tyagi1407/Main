import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { AttendGateComponent } from './components/attend-gate/attend-gate.component';
import { CobSpeechComponent } from './components/cob-speech/cob-speech.component';
import { PrmComponent } from './components/prm/prm.component';
import { BoardingSpeechComponent } from './components/boarding-speech/boarding-speech.component';
import { BoardingStartComponent } from './components/boarding-start/boarding-start.component';
import { PrintCrewlistComponent } from './components/print-crewlist/print-crewlist.component';
import { MisssingPassengerComponent } from './components/misssing-passenger/misssing-passenger.component';
import { CloseGateComponent } from './components/close-gate/close-gate.component';
import { GateDetailComponent } from './components/gate-detail/gate-detail.component';
import { GateHomeComponent } from './components/gate-home/gate-home.component';
import { GateRoutingModule } from './gate-routing.module';
import { HomeComponent } from './components/home/home.component';
import { TaskModule } from '../task/task.module';
import { DelayComponent } from './components/delay-speech/delay-speech.component';
import { StatusMessageComponent } from './components/status-message/status-message.component';



@NgModule({
  declarations: [GateHomeComponent, AttendGateComponent, CobSpeechComponent, PrmComponent, BoardingSpeechComponent, BoardingStartComponent, PrintCrewlistComponent,
    MisssingPassengerComponent, CloseGateComponent, GateDetailComponent, GateHomeComponent, HomeComponent, DelayComponent, StatusMessageComponent],
  imports: [CommonModule, GateRoutingModule, TaskModule],
  exports: [GateHomeComponent],
  providers:[DatePipe]

})
export class GateModule { }
