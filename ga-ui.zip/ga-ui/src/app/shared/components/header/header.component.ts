import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gateapp-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  time = new Date();

  constructor() { }

  ngOnInit() {

    setInterval(() => {
      this.time = new Date();
   }, 1000);

  }

}
