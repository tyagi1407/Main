import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
//models
//import { Task } from 'src/app/task/models/task.model';
import { Speech } from 'src/app/gate/models/speech.model';
import { Status } from 'src/app/task/models/status.model';
import { MissingPassenger } from 'src/app/gate/models/missing-passenger.model';
import { GateStatus } from 'src/app/gate/models/gate-status.model';
import { Flight } from 'src/app/task/models/flight.model';
import { HCCDelay } from 'src/app/gate/models/hcc-delay.model';
import { BoardingDelay } from 'src/app/gate/models/boarding-delay.model';

@Injectable({
  providedIn: 'root'
})


export class IntegrationService {

  speech: Speech;
  url: string = environment.apiIntegrationURL;

  constructor(private httpClient: HttpClient) { }


  //#region integration api methods

  getStatus(flightKey: string) {
    //http://localhost/integration/gate/status/lx45620191225
    return this.httpClient.get<Status[]>(this.url + '/gate/status/' + flightKey);
  }

  updateBoardingGateStatus(flightKey: string, status: string): any {
    let body = JSON.stringify(status);
    //http://localhost:53391/gate/status/update/aims/lx45620191225
    return this.httpClient.post<boolean>(this.url + '/gate/status/update/aims/' + flightKey, body, this.getOptions());
  }

  updateDelay(flightKey: string, boardingDelay: BoardingDelay): any {
    let body = JSON.stringify(boardingDelay);
    //console.log(body);
    //http://localhost/integration/gate/delay/update     
    return this.httpClient.post<boolean>(this.url + '/gate/delay/update/' + flightKey, body, this.getOptions());
  }

  updateStatus(status: Status): any {
    let body = JSON.stringify(status);
    //http://localhost/integration/gate/status/update  
    return this.httpClient.post<boolean>(this.url + '/gate/status/update', body, this.getOptions());
  }

  // getTaskDetails(userId: string) {
  //   //http://localhost/integration/tasks/gt305655
  //   return this.httpClient.get<Task[]>(this.url + '/tasks/' + userId);
  // }

  //get flights 90 mins before departure
  getFlights() {
    //http://localhost/integration/flights/lx
    return this.httpClient.get<Flight[]>(this.url + '/flights/lx');
  }

  getSpeech(flightKey: string, destination: string, type: string): Observable<Speech> {
    //http://localhost/integration/speeches/LX45620191225/BKK/cob    
    return this.httpClient.get<Speech>(this.url + '/speeches' + '/' + flightKey + '/' + destination + '/' + type);
  }

  getMissingPassenger(flightKey: string): Observable<MissingPassenger[]> {
    //http://localhost/integration/passengers/missing/LX45620191122
    return this.httpClient.get<MissingPassenger[]>(this.url + '/passengers/missing/' + flightKey);
  }

  getGateDetails(flightKey: string): Observable<GateStatus> {
    //http://localhost/integration/flights/LX45620191225    
    return this.httpClient.get<GateStatus>(this.url + '/gate/flights/' + flightKey);
  }

  boardPassenger(flightKey: string, customerId: string): any {
    let body = JSON.stringify(customerId);
    //console.log(this.url + '/passengers/board/' + flightKey);
    //console.log(body);
    return this.httpClient.post<boolean>(this.url + '/passengers/board/' + flightKey, body, this.getOptions());

  }
  offloadPassenger(flightKey: string, customerId: string): any {
    let body = JSON.stringify(customerId);
    //console.log(this.url + '/passengers/offload/' + flightKey);
    //console.log(body);
    return this.httpClient.post<boolean>(this.url + '/passengers/offload/' + flightKey, body, this.getOptions());
  }


  notifyHCC(flightKey: string, min: string, reason: string): any {
    let hccDelay: HCCDelay = { delayReason: reason, expectedBoardingDelay: min }
    let body = JSON.stringify(hccDelay);
    //console.log(this.url + '/notify/hcc/' + flightKey);
    //console.log(body);
    return this.httpClient.post<boolean>(this.url + '/notify/hcc/' + flightKey, body, this.getOptions());

  }
  notifyHCCForBagSearch(flightKey: string): any {    
    let body = '';    
    //console.log(body);
    //this.url='http://localhost:53391';
    return this.httpClient.post<boolean>(this.url + '/notify/bagsearch/' + flightKey, body, this.getOptions());

  }
  notifyVoice(flightKey: string): any {
    //let body = JSON.stringify('');    
    // console.log(this.url + '/notify/voice/' + flightKey);
    //flightKey='LX754020200224';    
    return this.httpClient.post<boolean>(this.url + '/notify/voice/' + flightKey, this.getOptions());

  }



  //private functions
  private getOptions(): any {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
    return options;
  }

  //#endregion

  //#region common functions use across components

  pad(num: number, size: number): string {
    let s = num + "";
    while (s.length < size) s = "0" + s;
    return s;
  }

  //#endregion



}


