import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewTaskComponent } from './components/view-task/view-task.component';




@NgModule({
  declarations: [ViewTaskComponent],
  imports: [
    CommonModule
  ],
  exports: [
    ViewTaskComponent
  ]
})
export class TaskModule { }
