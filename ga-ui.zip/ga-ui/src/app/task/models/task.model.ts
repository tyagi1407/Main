export class Task {
    userId: string;
    flightKey: string;
    flightCarrier: string;
    flightNumber: string;
    startTime: Date;
    endTime: Date;
    flight: Flight2
    taskStatus: string;
    gateStatus: Record<string, number>;
}

export class Flight2 {
    origin: string;
    destination: string;
    flightCarrier: string;
    flightNumber: string;
    gate: string;
    tarmac: string;
    scheduleTimeOfDeparture: Date;
    endTimeOfDeparture: Date;
}


