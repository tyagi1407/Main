export interface Status {
    flightKey?: string;
    estimatedTimeofDeparture?: Date;
    scheduleTimeofDeparture?: Date;
    name?: string;
    status: number;
    timeBeforeETD?: number;
    boardingDelay?:string;
    createTime?: Date;
    updateTime?: Date;

}
