export interface Flight {
    origin: string;
    destination: string;
    flightCarrier: string;
    gate: string;
    tarmac: string;
    scheduleTimeOfDeparture: Date;
    endTimeOfDeparture: Date;
    flightKey: string;
    flightNo: number;
    estimatedTimeofDeparture: Date;
    gateStatus: string;
    terminal: string;
    createTime: Date;
    currentProcess: string;
    updateTime: Date;
    flightStatus: string;
    gateActivityStatus: Record<string, number>;
}





