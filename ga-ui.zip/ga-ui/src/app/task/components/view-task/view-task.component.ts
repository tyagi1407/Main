import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { interval } from 'rxjs';
//service
import { IntegrationService } from 'src/app/core/services/integration.service';
//models
import { Status } from '../../models/status.model';
import { Flight } from '../../models/flight.model';

@Component({
  selector: 'gateapp-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit, AfterViewInit {

  flights: Flight[];
  status: Status[];
  activeFlightId: string;
  activateFlight: boolean;
  scrollIndex: number;
  @Input() userId: string;
  @Output() flightEvent = new EventEmitter<Flight[]>();


  constructor(private service: IntegrationService, private router: Router) { }

  ngOnInit() {
    this.getFlights();
    var t = interval(5000);
    //get data on specific interval
    t.subscribe(val => {
      this.getFlights();
    }
    );
  }

  ngAfterViewInit() {
    //TODO: dom initialization takes 1 sec(check 400 for one day flights)
    setTimeout(() => {
      document.getElementById('d' + this.scrollIndex).scrollIntoView(true);//{ behavior: 'smooth', block: 'start' }
      document.getElementById('m' + this.scrollIndex).scrollIntoView(true);
    }, 1000)

  }

  private getFlights() {
    this.service.getFlights().subscribe((data) => {
      this.flights = data;
      this.flightEvent.emit(this.flights);
      //console.log(this.flights);          
      this.scrollIndex = this.flights.findIndex(x => new Date(x.scheduleTimeOfDeparture) > new Date() && x.flightStatus == 'NOT STARTED');
      if (this.scrollIndex == -1)
        this.scrollIndex = this.flights.length - 1;
      //console.log(this.scrollIndex);
      //console.log(this.flights[0].gateActivityStatus['abc']); 
    });
  }



  onDskFlightClick(flightKey, destination, flightStatus) {
    //console.log(flightKey);   
    this.activeFlightId = flightKey;
    this.router.navigate(['flights', this.userId], { queryParams: { flightKey: flightKey, dest: destination, sts: flightStatus } });

  }
  onMobFlightClick(flightKey, destination, flightStatus) {
    this.activeFlightId = flightKey;
    this.router.navigate(['gate'], { queryParams: { flightKey: flightKey, dest: destination, sts: flightStatus } });
  }

  // private activateFlight90MinsBeforeDeparture(notStartedFlight: Flight[]) {
  //   if (notStartedFlight) {

  //     var etd = new Date(notStartedFlight[0].estimatedTimeofDeparture).getTime();
  //     var now = new Date().getTime();
  //     var interval = etd - now;
  //     var minutes = Math.round(interval / (1000 * 60));
  //     console.log(minutes);
  //     if (minutes >= 0 && minutes < 90) {
  //       this.activateFlight = true;
  //       console.log(this.activateFlight);
  //     }
  //   }
  // }

  // private getStatus() {
  //   this.service.getStatus(this.flightKey).subscribe((data) => {
  //     this.status = data;
  //   });
  // }



}
